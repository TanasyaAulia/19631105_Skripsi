<footer class="page-footer">
    <p class="mb-0">Copyright © <a href="https://www.youtube.com/channel/UC9YMfcfLwhouNSpFwJ69_LA" target="_bank">Simawar</a> <?php echo date("Y") ?>. All right reserved.</p>
</footer>