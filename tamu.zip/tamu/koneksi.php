<?php
$conn = mysqli_connect("localhost", "root", "", "tamu");

date_default_timezone_set("Asia/Singapore");
