<?php
session_start();
include "koneksi.php";

if (isset($_POST["submit"])) {

    $username = $_POST["username"];
    $password = $_POST["password"];

    $result = mysqli_query($conn, "SELECT * FROM user WHERE username = '$username' && status = 1");

    if (mysqli_num_rows($result) === 1) {

        $row = mysqli_fetch_assoc($result);

        if (password_verify($password, $row["password"])) {
            $_SESSION["login"] = true;
            $_SESSION["id"] = $row["id"];
            $_SESSION["level"] = $row["level"];


            if ($row["level"] == 1) {
                header("Location: sadmin/index.php");
            } else if ($row["level"] == 2) {
                header("Location: pegawai/index.php");
            } else if ($row["level"] == 3) {
                header("Location: user/index.php");
            } 
            exit;
        }
    }
    $error = true;
}
?>
<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="icon" href="assets/images/logo2.png" type="image/png" />
    <link href="assets/plugins/simplebar/css/simplebar.css" rel="stylesheet" />
    <link href="assets/plugins/perfect-scrollbar/css/perfect-scrollbar.css" rel="stylesheet" />
    <link href="assets/plugins/metismenu/css/metisMenu.min.css" rel="stylesheet" />
    <link href="assets/css/pace.min.css" rel="stylesheet" />
    <script src="assets/js/pace.min.js"></script>
    <link href="assets/css/bootstrap.min.css" rel="stylesheet">
    <link href="assets/css/app.css" rel="stylesheet">
    <link href="assets/css/icons.css" rel="stylesheet">
    <title>Isi Buku Tamu</title>
    
</head>

<body class="bg-login">
    
    <div class="wrapper">
        <div class="section-authentication-signin d-flex align-items-center justify-content-center my-3 my-lg-0">
            <div class="content">
                <div class="row row-cols-1 row-cols-lg-4 row-cols-xl-1">
                    <div class="col mx-auto">
                        <div class="text-center my-4">
                            <img src="assets/images/logoaja.png" width="300" alt="" />
                        </div>
                        <div class="card">
                            <div class="card-body">
                                <div class="border p-4 rounded">

                                    <div class="text-center">
                                        <h6>APLIKASI PENGEMBANGAN SISTEM BUKU TAMU ELEKTRONIK DALAM MENGELOLA PELAYANAN TAMU</h6>
                                           <h6>KANTOR ADMINISTRASI ANGKASA PURA 1 BANDAR UDARA SYAMSUDIN NOOR BANJARMASIN </h6>  
                                        <div class="login-separater text-center mb-4"> <span>Silahkan Pilih Opsi Dibawah Ini Sesuai dengan <b>Keperluan</b> Anda</span>
                                        <?php if (isset($_SESSION['nama_tamu'])){ ?>
                                        <div class="login-separater text-center mb-4"> <span>Selamaat Datang, <b><?= $_SESSION['nama_tamu']; ?></b></span>
                                        <?php } ?>
                                        <hr />
                                        <br>
                                            <div class="btn-group-vertical">
                                                <a class="btn btn-outline-secondary " href="sadmin/pengunjung_isi.php" role="button">Kunjungan ke Pegawai</a>
                                                <a class="btn btn-outline-secondary mt-2" href="sadmin/penawaran_isi.php" role="button">Penawaran Jasa/Produk</a>
                                                <a class="btn btn-outline-secondary mt-2" href="sadmin/cm_isi.php" role="button">Pendaftaran Calon Mitra</a>
                                                <a class="btn btn-outline-secondary mt-2" href="sadmin/berkas_isi.php" role="button">Penerimaan Berkas/Dokumen</a>
                                                <a class="btn btn-outline-secondary mt-2" href="sadmin/paket_isi.php" role="button">Penerimaan Paket</a>

                                            </div>
                                        </div>
                                        </form>
                                        <div class="col-md-12 text-center"> 
                                           Sudah Pernah Mengisi Keperluan Data?  <a href="login_biasa.php"><b>Klik Disini</b></a>
                                        </div>
                                        <br>
                                        <div class="col-md-12 text-center"> 
                                            <a href="login.php">Masuk sebagai <b>General Service?</b></a>
                                        </div>
                                        <div class="col-md-12 text-center"> <a href="login_pegawai.php">Masuk sebagai <b>Pegawai?</b></a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <footer class="sticky-footer bg-white">
        <div class="container my-auto">
            <div class="copyright text-center my-auto">
                <span>
                    <a href="#" target="_blank"><?= date('j F Y') ?></a> &copy; Angkasa Pura 1 </span>
            </div>
        </div>
    </footer>
    <script src="assets/js/bootstrap.bundle.min.js"></script>
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/js/simplebar.min.js"></script>
    <script src="assets/js/metisMenu.min.js"></script>
    <script src="assets/js/perfect-scrollbar.js"></script>
    <script src="assets/js/app.js"></script>
</body>

</html> 