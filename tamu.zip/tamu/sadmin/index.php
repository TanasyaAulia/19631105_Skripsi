<?php

session_start();

if ($_SESSION["level"] == 2 or $_SESSION["level"] == 3 or $_SESSION["level"] == 4) {
    header("Location: logout.php");
    exit;
}

if (!isset($_SESSION["login"])) {
    header("Location:index.php");
    exit;
}

include "../koneksi.php";

$id = $_SESSION["id"];

$query_user = "SELECT * FROM user";
$result_user = mysqli_query($conn, $query_user);
$row_user = mysqli_fetch_assoc($result_user);


if ($_SESSION["level"]<>'Pegawai'){
    
    $query_pengunjung = "SELECT * FROM pengunjung ORDER BY id_tamu DESC LIMIT 5";
}else{
    $query_pengunjung = "SELECT * FROM pengunjung WHERE id_pegawai='$_SESSION[id]' ORDER BY id_tamu DESC LIMIT 5";
}
$result_pengunjung = mysqli_query($conn, $query_pengunjung);



?>

<!doctype html>
<html lang="en" class="<?php echo $row_user["theme"] ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="icon" href="../assets/images/logo2.png" type="image/png" />
    <link href="../assets/plugins/simplebar/css/simplebar.css" rel="stylesheet" />
    <link href="../assets/plugins/perfect-scrollbar/css/perfect-scrollbar.css" rel="stylesheet" />
    <link href="../assets/plugins/highcharts/css/highcharts.css" rel="stylesheet" />
    <link href="../assets/plugins/vectormap/jquery-jvectormap-2.0.2.css" rel="stylesheet" />
    <link href="../assets/plugins/metismenu/css/metisMenu.min.css" rel="stylesheet" />
    <link href="../assets/css/pace.min.css" rel="stylesheet" />
    <script src="../assets/js/pace.min.js"></script>
    <!-- Bootstrap CSS -->
    <link href="../assets/css/bootstrap.min.css" rel="stylesheet">
    <link href="../assets/css/app.css" rel="stylesheet">
    <link href="../assets/css/icons.css" rel="stylesheet">
    <!-- Theme Style CSS -->
    <link rel="stylesheet" href="../assets/css/dark-theme.css" />
    <link rel="stylesheet" href="../assets/css/semi-dark.css" />
    <link rel="stylesheet" href="../assets/css/header-colors.css" />
    <title>Angkasa Pura 1</title>
</head>

<body>
    <!--wrapper-->
    <div class="wrapper">

    <?php include "theme-header.php" ?>
        <?php include "theme-sidebar.php" ?>


        <!--start page wrapper -->
        <div class="page-wrapper">
            <div class="page-content">

                <div class="row row-cols-1 row-cols-lg-2 row-cols-xl-4">

                    <?php
                    $query_user = "SELECT * FROM user";
                    $result_user = mysqli_query($conn, $query_user);
                    $jumlah_user = mysqli_num_rows($result_user);
                    ?>

                    <div class="col">
                        <div class="card radius-10 overflow-hidden bg-danger">
                            <div class="card-body">
                                <div class="d-flex align-items-center">
                                    <div>
                                        <p class="mb-0 text-white">Data User</p>
                                        <h5 class="mb-0 text-white"><?php echo $jumlah_user ?></h5>
                                    </div>
                                    <div class="ms-auto text-white"> <i class='bx bxs-user-check font-30' ></i>
                                    </div>
                                </div>
                            </div>
                            <div class="" id="chart1"></div>
                        </div>
                    </div>

                    <?php
                  if ($_SESSION["level"]<>'Pegawai'){
                    $query_pengunjung = "SELECT * FROM pengunjung ORDER BY id_tamu DESC LIMIT 5";
                    $query_pengunjung1 = "SELECT * FROM pengunjung";
                }else{
                    $query_pengunjung1 = "SELECT * FROM pengunjung WHERE id_pegawai='$_SESSION[id]'";
                    $query_pengunjung = "SELECT * FROM pengunjung WHERE id_pegawai='$_SESSION[id]' ORDER BY id_tamu DESC LIMIT 5";
                }
                
                    $result_pengunjung = mysqli_query($conn, $query_pengunjung);
                    $result_pengunjung1 = mysqli_query($conn, $query_pengunjung1);
                    $jumlah_pengunjung = mysqli_num_rows($result_pengunjung1);
                    ?>
                    <div class="col">
                        <div class="card radius-10 overflow-hidden bg-primary">
                            <div class="card-body">
                                <div class="d-flex align-items-center">
                                    <div>
                                        <p class="mb-0 text-white">Data Pengunjung</p>
                                        <h5 class="mb-0 text-white"><?php echo $jumlah_pengunjung ?></h5>
                                    </div>
                                    <div class="ms-auto text-white"> <i class='bx bx-import font-30'></i>
                                    </div>
                                </div>
                            </div>
                            <div class="" id="chart2"></div>
                        </div>
                    </div>
                    <?php
                    if ($_SESSION["level"]<>'Pegawai'){
                        $query_berkas = "SELECT * FROM berkas ORDER BY id_berkas DESC";
                    }else{
                        $query_berkas = "SELECT * FROM berkas WHERE id_bagian='$_SESSION[id]' ORDER BY id_berkas DESC";
                    }
                    $result_berkas = mysqli_query($conn, $query_berkas);
                    $jumlah_berkas = mysqli_num_rows($result_berkas);
                    ?>

                    <div class="col">
                        <div class="card radius-10 overflow-hidden bg-warning">
                            <div class="card-body">
                                <div class="d-flex align-items-center">
                                    <div>
                                        <p class="mb-0 text-dark">Data Berkas</p>
                                        <h5 class="mb-0 text-dark"><?php echo $jumlah_berkas ?></h5>
                                    </div>
                                    <div class="ms-auto text-dark"> <i class='bx bx-envelope font-30'></i>
                                    </div>
                                </div>
                            </div>
                            <div class="" id="chart3"></div>
                        </div>
                    </div>

                    <?php
                   if ($_SESSION["level"]<>'Pegawai'){
                    $query_paket = "SELECT * FROM paket ORDER BY id_paket DESC LIMIT 5";
                    $query_paket1 = "SELECT * FROM paket";
                }else{
                    $query_paket = "SELECT * FROM paket WHERE id_pegawai='$_SESSION[id]' ORDER BY id_paket DESC LIMIT 5";
                    $query_paket1 = "SELECT * FROM paket WHERE id_pegawai='$_SESSION[id]'";
                }
                    $result_paket1 = mysqli_query($conn, $query_paket1);
                    $jumlah_paket = mysqli_num_rows($result_paket1);
                    $result_paket = mysqli_query($conn, $query_paket);
                    // $jumlah_paket = mysqli_num_rows($result_paket);
                    
                    ?>
                    <div class="col">
                        <div class="card radius-10 overflow-hidden bg-success">
                            <div class="card-body">
                                <div class="d-flex align-items-center">
                                    <div>
                                        <p class="mb-0 text-white">Data Paket</p>
                                        <h5 class="mb-0 text-white"><?php echo $jumlah_paket ?></h5>
                                    </div>
                                    <div class="ms-auto text-white"> <i class='bx bx-envelope-open font-30'></i>
                                    </div>
                                </div>
                            </div>
                            <div class="" id="chart4"></div>
                        </div>
                    </div>
                </div>
                <!--end row-->
                <!--end row-->
                <div class="row">
                    <div class="col">
                        <h5 class="my-4 text-uppercase">Data Pengunjung Masuk</h5>
                              

                                <?php if ($_SESSION["level"]<>'Pegawai'){ ?>
        <?php } ?>
        <div class="card">
                    <div class="card-body">
                        <div class="table-responsive">
                            <table id="example2" class="table table-hover table-bordered">
                                <thead class="table-primary">
                                <tr>
                                        <th>No.</th>
                                        <th>Status</th>
                                        <th>Tanggal</th>
                                        <th>Nama Pengunjung</th>
                                        <th>Alamat</th>
                                        <th>Telepon</th>
                                        <th>Pegawai yang Dikunjungi</th>
                                        <th>Tujuan</th>
                                    </tr>
                                </thead>
                                <tbody>
                                <?php
                                $no = 0;
                                if ($_SESSION["level"]<>'Pegawai'){
                                    $query_pegawai = mysqli_query($conn, "SELECT * FROM pegawai ");
                                }else{
                                    $query_pegawai = mysqli_query($conn, "SELECT * FROM pegawai WHERE id_pegawai='$_SESSION[id]'");
                                }
                                $pegawai_data = array();
                                while ($row_pegawai = mysqli_fetch_assoc($query_pegawai)) {
                                    $pegawai_data[$row_pegawai['id_pegawai']] = $row_pegawai['nama_pegawai'];
                                }

                                while ($row_pengunjung = mysqli_fetch_assoc($result_pengunjung)) { 

                                    $no++;
                                    $status = $row_pengunjung ['status'];
                                    $tanggal = $row_pengunjung ['tanggal'];
                                    $nama_tamu = $row_pengunjung ['nama_tamu'];
                                    $alamat = $row_pengunjung ['alamat'];
                                    $telp = $row_pengunjung ['telp'];
                                     if ($_SESSION["level"]<>'Pegawai'){
                                        $id_pegawai = $row_pengunjung ['id_pegawai'];
                                    }else{
                                         $id_pegawai = $_SESSION["id"];
                                     }
                                    $nama_pegawai = isset($pegawai_data[$id_pegawai]) ? $pegawai_data[$id_pegawai] : '';
                                    $tujuan = $row_pengunjung ['tujuan'];
                                    
                                    ?>
                                    <tr>
                                        <td><?= $no ?></td>
                                        <td>
                                            <?php if ($row_pengunjung["status"] == 1) { ?>
                                                <span class="badge bg-light-danger text-danger w-100"> Belum Ditemui </span>
                                            <?php } else if ($row_pengunjung["status"] == 2) { ?>
                                                <span class="badge bg-light-warning text-dark w-100"> Proses </span>
                                            <?php } else if ($row_pengunjung["status"] == 3) { ?>
                                                <span class="badge bg-light-success text-success w-100"> Sudah Ditemui</span>
                                            <?php } ?>
                                        </td>
                                       
                                        <td><?= $tanggal ?></td>
                                        <td><?= $nama_tamu ?></td>
                                        <td><?= $alamat ?> </td>
                                        <td><a href="tel:<?php echo $row_pengunjung["telp"] ?>"><?php echo $row_pengunjung["telp"] ?></a> </td>
                                        <td><b><?=  $nama_pegawai ?></b></td>
                                        <td><?php echo $row_pengunjung["tujuan"] ?></td>
                                       
                                        </td>
                                    </tr>
                                    <?php } ?>
</tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                <!--end row-->
                <h5 class="my-4 text-uppercase">Data Paket Masuk</h5>
                <div class="col">
        <?php if ($_SESSION["level"]<>'Pegawai'){ ?>
        <?php } ?>
                </div>
                <div class="card">
                    <div class="card-body">
                        <div class="table-responsive">
                            <table id="example2" class="table table-hover table-bordered">
                                <thead class="table-primary">
                                    <tr>
                                        <th>No.</th>
                                        <th>Tanggal</th>
                                        <th>No. Resi</th>
                                        <th>Jenis</th>
                                        <th>Nama</th>
                                        <th>Alamat</th>
                                        <th>Telepon</th>
                                        <th>Ekspedisi</th>
                                        <th>Tujuan</th>
                                    </tr>
                                </thead>
                                <?php
    $no = 0;
    while ($row_paket = mysqli_fetch_assoc($result_paket)) { 
    $no++;    
        ?>
        <tr>
        <td><?= $no ?></td>
            <td><?php echo $row_paket["tanggal"] ?></td>
            <td><b><?php echo $row_paket["no_resi"] ?></b></td>
            <td><?php echo $row_paket["jenis"] ?></td>
            <td><?php echo $row_paket["nama"] ?></td>
            <td><?php echo $row_paket["alamat"] ?></td>
            <td><a href="tel:<?php echo $row_paket["telp"] ?>"><?php echo $row_paket["telp"] ?></a></td>
            <td><b><?php echo $row_paket["ekspedisi"] ?></b></td>
            <td>
                <?php 
                $query_pegawai = "SELECT P.nama_pegawai FROM pegawai P, paket PA WHERE PA.id_pegawai = P.id_pegawai AND PA.id_paket = " . $row_paket["id_paket"];
                $result_pegawai = mysqli_query($conn, $query_pegawai);
                while ($row_pegawai = mysqli_fetch_assoc($result_pegawai)) {
                    echo $row_pegawai["nama_pegawai"];
                }
                ?>
            </td>
           
        </tr>
    <?php } ?>
</tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!--end row-->

            </div>
        </div>
        <!--end page wrapper -->
        <!--start overlay-->
        <div class="overlay toggle-icon"></div>
        <!--end overlay-->
        <!--Start Back To Top Button--> <a href="javaScript:;" class="back-to-top"><i class='bx bxs-up-arrow-alt'></i></a>
        <!--End Back To Top Button-->

        <?php include "theme-footer.php" ?>

    </div>
    <!--end wrapper-->
    <!-- Bootstrap JS -->
    <script src="../assets/js/bootstrap.bundle.min.js"></script>
    <!--plugins-->
    <script src="../assets/js/jquery.min.js"></script>
    <script src="../assets/plugins/simplebar/js/simplebar.min.js"></script>
    <script src="../assets/plugins/metismenu/js/metisMenu.min.js"></script>
    <script src="../assets/plugins/perfect-scrollbar/js/perfect-scrollbar.js"></script>
    <script src="../assets/plugins/vectormap/jquery-jvectormap-2.0.2.min.js"></script>
    <script src="../assets/plugins/vectormap/jquery-jvectormap-world-mill-en.js"></script>
    <script src="../assets/plugins/highcharts/js/highcharts.js"></script>
    <script src="../assets/plugins/highcharts/js/exporting.js"></script>
    <script src="../assets/plugins/highcharts/js/variable-pie.js"></script>
    <script src="../assets/plugins/highcharts/js/export-data.js"></script>
    <script src="../assets/plugins/highcharts/js/accessibility.js"></script>
    <script src="../assets/plugins/apexcharts-bundle/js/apexcharts.min.js"></script>
    <script src="../assets/js/index.js"></script>
    <!--app JS-->
    <script src="../assets/js/app.js"></script>
    <script>
        new PerfectScrollbar('.customers-list');
        new PerfectScrollbar('.store-metrics');
        new PerfectScrollbar('.product-list');
    </script>
</body>

</html>