<?php
session_start();
include "../koneksi.php";

$id = $_SESSION["id"];

$query_user = "SELECT * FROM user";
$result_user = mysqli_query($conn, $query_user);
$row_user = mysqli_fetch_assoc($result_user);


?>
<!doctype html>
<html lang="en" class="<?php echo $row_user["theme"] ?>">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!--favicon-->
    <link rel="icon" href="../assets/images/logo2.png" type="image/png" />
    <!--plugins-->
    <link href="../assets/plugins/simplebar/css/simplebar.css" rel="stylesheet" />
    <link href="../assets/plugins/perfect-scrollbar/css/perfect-scrollbar.css" rel="stylesheet" />
    <link href="../assets/plugins/metismenu/css/metisMenu.min.css" rel="stylesheet" />
    <!-- loader-->
    <link href="../assets/css/pace.min.css" rel="stylesheet" />
    <script src="../assets/js/pace.min.js"></script>
    <!-- Bootstrap CSS -->
    <link href="../assets/css/bootstrap.min.css" rel="stylesheet">
    <link href="../assets/css/app.css" rel="stylesheet">
    <link href="../assets/css/icons.css" rel="stylesheet">
    <!-- Theme Style CSS -->
    <link rel="stylesheet" href="../assets/css/dark-theme.css" />
    <link rel="stylesheet" href="../assets/css/semi-dark.css" />
    <link rel="stylesheet" href="../assets/css/header-colors.css" />


    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>

    <title>Laporan Calon Mitra Binaan (Proses Verifikasi)</title>
</head>

<body>
    <!--wrapper-->
    <div class="wrapper">

        <?php include "theme-sidebar.php" ?>

        <?php include "theme-header.php" ?>

        <!--start page wrapper -->
        <div class="page-wrapper">
            <div class="page-content">
                <!--breadcrumb-->
                <div class="page-breadcrumb d-none d-sm-flex align-items-center mb-3">
                    <div class="ps-3">
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb mb-0 p-0">
                                <li class="breadcrumb-item"><a href="index.php"><i class="bx bx-home-alt"></i></a></li>
                                <li class="breadcrumb-item"><a href="laporan_pengunjung.php">Laporan Calon Mitra Binaan (Proses Verifikasi)</a></li>
                            </ol>
                        </nav>
                    </div>
                </div>
                <!--end breadcrumb-->
                <div class="row">
                    <div class="col-xl-10 mx-auto">
                        <br>    
                        <div class="card border-top border-0 border-4 border-primary">
                            <div class="card-body px-5 pb-5">
                                <div class="card-title d-flex align-items-center">
                                    <h5 class="mb-0 text-primary">Laporan Calon Mitra Binaan (Proses Verifikasi)</h5>
                                </div>
                                <hr>
                                <div class="card-body">
										<div class="row">
											<div class="col-lg-12 col-md-12">
												<ul class="nav nav-tabs" id="myTab" role="tablist">
													<li class="nav-item">
														<a class="nav-link <?php if( (isset($_GET['submit']) && (isset($_GET['tipe']) && $_GET['tipe'] == 'pertanggal')) || empty($_GET['submit']) ) { echo 'active'; } ?>" id="pertanggal-tab" data-toggle="tab" href="#pertanggal" role="tab" aria-controls="pertanggal" aria-selected="false">Pertanggal</a>
													</li>
													<li class="nav-item">
														<a class="nav-link <?php if(isset($_GET['submit']) && (isset($_GET['tipe']) && $_GET['tipe'] == 'perbulan')) { echo 'active'; } ?>" id="perbulan-tab" data-toggle="tab" href="#perbulan" role="tab" aria-controls="perbulan" aria-selected="true">Perbulan</a>
													</li>
													<li class="nav-item">
														<a class="nav-link <?php if(isset($_GET['submit']) && (isset($_GET['tipe']) && $_GET['tipe'] == 'pertahun')) { echo 'active'; } ?>" id="pertahun-tab" data-toggle="tab" href="#pertahun" role="tab" aria-controls="pertahun" aria-selected="true">Pertahun</a>
													</li>
												</ul>
											</div>
										</div>
										<div class="row mt-4">
											<div class="col-lg-12 col-md-12">
												<div class="tab-content" id="myTabContent">
													<div class="tab-pane fade <?php if( (isset($_GET['submit']) && (isset($_GET['tipe']) && $_GET['tipe'] == 'pertanggal')) || empty($_GET['submit']) ) { echo 'in active'; } ?>" id="pertanggal" role="tabpanel" aria-labelledby="pertanggal-tab">
														<div class="row">
															<div class="col-md-12">
																<form action="" method="GET" id="form_tambah">
																	<input type="hidden" name="tipe" id="tipe" value="pertanggal">
																	<div class="row">
																		<div class="col-md-6">
																			<div class="form-group">
																				<label for="from">Dari Tanggal</label>
																				<input type="date" name="from" id="from" required="" class="form-control" <?php if( (isset($_GET['tipe']) && $_GET['tipe'] == "pertanggal") && (isset($_GET['from']) && !empty($_GET['from'])) ) {echo "value='".date('Y-m-d', strtotime($_GET['from']))."'";} ?>>
																			</div>
																		</div>
																		<div class="col-md-6">
																			<div class="form-group">
																				<label for="to">Sampai Tanggal</label>
																				<input type="date" name="to" id="to" required="" class="form-control" <?php if( (isset($_GET['tipe']) && $_GET['tipe'] == "pertanggal") && (isset($_GET['to']) && !empty($_GET['to'])) ) {echo "value='".date('Y-m-d', strtotime($_GET['to']))."'";} ?>>
																			</div>
																		</div>
																		<div class="col-md-12">
																			<div class="form-group">
																				<button type="submit" class="btn btn-primary float-right" name="submit" value="show">Tampilkan Data</button>
																			</div>
																		</div>
																	</div>
																</form>
															</div>
														</div>
													</div>
													<div class="tab-pane fade <?php if(isset($_GET['submit']) && (isset($_GET['tipe']) && $_GET['tipe'] == 'perbulan')) { echo 'in active'; } ?>" id="perbulan" role="tabpanel" aria-labelledby="perbulan-tab">
														<div class="row">
															<div class="col-md-12">
																<form action="" method="GET" id="form_tambah">
																	<input type="hidden" name="tipe" id="tipe" value="perbulan">
																	<div class="row">
																		<div class="col-md-6">
																			<div class="form-group">
																				<label for="bulan">Bulan</label>
																				<select class="form-control select2" name="bulan" id="bulan" required="" style="width: 100%;">
																					<option value="">Pilih Bulan</option>
																					<option value="01" <?php if((isset($_GET['tipe']) && $_GET['tipe'] == "perbulan") && (isset($_GET['bulan']) && !empty($_GET['bulan'])) && $_GET['bulan'] == "01") { echo "selected='selected'"; }?>>Januari</option>
																					<option value="02" <?php if((isset($_GET['tipe']) && $_GET['tipe'] == "perbulan") && (isset($_GET['bulan']) && !empty($_GET['bulan'])) && $_GET['bulan'] == "02") { echo "selected='selected'"; }?>>Februari</option>
																					<option value="03" <?php if((isset($_GET['tipe']) && $_GET['tipe'] == "perbulan") && (isset($_GET['bulan']) && !empty($_GET['bulan'])) && $_GET['bulan'] == "03") { echo "selected='selected'"; }?>>Maret</option>
																					<option value="04" <?php if((isset($_GET['tipe']) && $_GET['tipe'] == "perbulan") && (isset($_GET['bulan']) && !empty($_GET['bulan'])) && $_GET['bulan'] == "04") { echo "selected='selected'"; }?>>April</option>
																					<option value="05" <?php if((isset($_GET['tipe']) && $_GET['tipe'] == "perbulan") && (isset($_GET['bulan']) && !empty($_GET['bulan'])) && $_GET['bulan'] == "05") { echo "selected='selected'"; }?>>Mei</option>
																					<option value="06" <?php if((isset($_GET['tipe']) && $_GET['tipe'] == "perbulan") && (isset($_GET['bulan']) && !empty($_GET['bulan'])) && $_GET['bulan'] == "06") { echo "selected='selected'"; }?>>Juni</option>
																					<option value="07" <?php if((isset($_GET['tipe']) && $_GET['tipe'] == "perbulan") && (isset($_GET['bulan']) && !empty($_GET['bulan'])) && $_GET['bulan'] == "07") { echo "selected='selected'"; }?>>Juli</option>
																					<option value="08" <?php if((isset($_GET['tipe']) && $_GET['tipe'] == "perbulan") && (isset($_GET['bulan']) && !empty($_GET['bulan'])) && $_GET['bulan'] == "08") { echo "selected='selected'"; }?>>Agustus</option>
																					<option value="09" <?php if((isset($_GET['tipe']) && $_GET['tipe'] == "perbulan") && (isset($_GET['bulan']) && !empty($_GET['bulan'])) && $_GET['bulan'] == "09") { echo "selected='selected'"; }?>>September</option>
																					<option value="10" <?php if((isset($_GET['tipe']) && $_GET['tipe'] == "perbulan") && (isset($_GET['bulan']) && !empty($_GET['bulan'])) && $_GET['bulan'] == "10") { echo "selected='selected'"; }?>>Oktober</option>
																					<option value="11" <?php if((isset($_GET['tipe']) && $_GET['tipe'] == "perbulan") && (isset($_GET['bulan']) && !empty($_GET['bulan'])) && $_GET['bulan'] == "11") { echo "selected='selected'"; }?>>November</option>
																					<option value="12" <?php if((isset($_GET['tipe']) && $_GET['tipe'] == "perbulan") && (isset($_GET['bulan']) && !empty($_GET['bulan'])) && $_GET['bulan'] == "12") { echo "selected='selected'"; }?>>Desember</option>
																				</select>
																			</div>
																		</div>
																		<div class="col-md-6">
																			<div class="form-group">
																				<label for="tahun">Tahun</label>
																				<select class="form-control select2" name="tahun" id="tahun" required="" style="width: 100%;">
																					<option value="">Pilih Tahun</option>
																					<?php
																					$mulai = date('Y') - 50;
																					for($i = $mulai; $i < $mulai + 100; $i++){

																						if((isset($_GET['tipe']) && $_GET['tipe'] == "perbulan") && (isset($_GET['tahun']) && !empty($_GET['tahun']))) {
																							$sel = $_GET['tahun'] == $i ? "selected='selected'" : '';
																						}else {
																							$sel = $i == date('Y') ? "selected=''" : '';
																						}
																						?>
																						<option value="<?= $i;?>" <?= $sel;?>><?= $i;?></option>
																					<?php } ?>
																				</select>
																			</div>
																		</div>
																		<div class="col-md-12">
																			<div class="form-group">
																				<button type="submit" class="btn btn-primary float-right" name="submit" value="show">Tampilkan Data</button>
																			</div>
																		</div>
																	</div>
																</form>
															</div>
														</div>
													</div>
													<div class="tab-pane fade <?php if(isset($_GET['submit']) && (isset($_GET['tipe']) && $_GET['tipe'] == 'pertahun')) { echo 'in active'; } ?>" id="pertahun" role="tabpanel" aria-labelledby="pertahun-tab">
														<div class="row">
															<div class="col-md-12">
																<form action="" method="GET" id="form_tambah">
																	<input type="hidden" name="tipe" id="tipe" value="pertahun">
																	<div class="row">
																		<div class="col-md-6">
																			<div class="form-group">
																				<label for="tahun">Tahun</label>
																				<select class="form-control select2" name="tahun" id="tahun" required="" style="width: 100%;">
																					<option value="">Pilih Tahun</option>
																					<?php
																					$mulai = date('Y') - 50;
																					for($i = $mulai; $i < $mulai + 100; $i++){

																						if((isset($_GET['tipe']) && $_GET['tipe'] == "pertahun") && (isset($_GET['tahun']) && !empty($_GET['tahun']))) {
																							$sel = $_GET['tahun'] == $i ? "selected='selected'" : '';
																						}else {
																							$sel = $i == date('Y') ? "selected=''" : '';
																						}
																						?>
																						<option value="<?= $i;?>" <?= $sel;?>><?= $i;?></option>
																					<?php } ?>
																				</select>
																			</div>
																		</div>
																		<div class="col-md-12">
																			<div class="form-group">
																				<button type="submit" class="btn btn-primary float-right" name="submit" value="show">Tampilkan Data</button>
																			</div>
																		</div>
																	</div>
																</form>
															</div>
														</div>
													</div>
												</div>
											</div>
										</div>
										<div class="row mt-4">
											<div class="col-lg-12 col-md-12">
												<?php if(isset($_GET['submit'])) { ?>

													<?php if(isset($_GET['tipe'])) { ?>

														<?php if($_GET['tipe'] == "pertanggal") { 
															$from = $_GET['from'];
															$to = $_GET['to']; 
															?>
															<a href="cm_print2.php?tipe=pertanggal&from=<?= $from; ?>&to=<?= $to; ?>" target="_blank" class="btn btn-success">
																Cetak
															</a>
														<?php }else if($_GET['tipe'] == "perbulan") { 
															$bulan = $_GET['bulan'];
															$tahun = $_GET['tahun'];
															?>
															<a href="cm_print2.php?tipe=perbulan&bulan=<?= $bulan; ?>&tahun=<?= $tahun; ?>" target="_blank" class="btn btn-success">
																Cetak
															</a>
														<?php }else if($_GET['tipe'] == "pertahun") { 
															$tahun = $_GET['tahun'];
															?>
															<a href="cm_print2.php?tipe=pertahun&tahun=<?= $tahun; ?>" target="_blank" class="btn btn-success">
																Cetak
															</a>
														<?php }else { ?>
															<a href="cm_print2.php" target="_blank" class="btn btn-success">
																Cetak
															</a>
														<?php } ?>

													<?php }else { ?>
														<a href="cm_print2.php" target="_blank" class="btn btn-success">
															Cetak
														</a>
													<?php } ?>

												<?php }else { ?>
													<a href="cm_print2.php" target="_blank" class="btn btn-success">
														Cetak
													</a>
													<?php } ?>
													<?php if(isset($_GET['submit'])){ ?>
														<a href="laporan_cm2.php" class="btn btn-danger">
															<!-- <i class="fas fa-signout"></i>  -->
															Bersihkan
														</a>
													<?php } ?>
											</div>
										</div>
										<div class="row mt-4">
											<div class="col-lg-12 col-md-12">
												<div class="table-responsive">
													<table class="display table table-striped table-hover datatables" id="table-1">
														<thead>
															<tr>
																<th width="2%">No.</th>
																<th width="15%">Nama Lengkap</th>
																<th width="10%">Alamat</th>
																<th width="10%">No. Telepon</th>
																<th width="10%">Sektor</th>
																<th width="10%">Produk</th>
																<th width="15%">Penghasilan</th>
																<th width="5%">Jangka Waktu</th>
																<th width="10%">Status</th>
																<th width="10%">Tanggal</th>
															</tr>
														</thead>
														<tbody>
															<?php 
															$no = 1;
															if(isset($_GET['submit'])) {
																
																if(isset($_GET['tipe'])) {
																	
																	if($_GET['tipe'] == "pertanggal") {
																		$from = $_GET['from'];
																		$to = $_GET['to']; 
																		
																		$query = mysqli_query($conn, "SELECT * FROM calon_mitra WHERE DATE(tanggal) BETWEEN '$from' AND '$to' AND status = 2 ORDER BY id_cm ASC");
																	}else if($_GET['tipe'] == "perbulan") {
																		$bulan = $_GET['bulan'];
																		$tahun = $_GET['tahun'];
																		
																		$query = mysqli_query($conn, "SELECT * FROM calon_mitra WHERE DATE(tanggal) LIKE '$tahun-$bulan%' AND status = 2 ORDER BY id_cm ASC");
																	}else if($_GET['tipe'] == "pertahun") {
																		$tahun = $_GET['tahun'];

																		$query = mysqli_query($conn, "SELECT * FROM calon_mitra WHERE tanggal LIKE '$tahun%' AND status = 2 ORDER BY id_cm ASC");
																	}else {
																		$query = mysqli_query($conn, "SELECT * FROM calon_mitra WHERE status = 2 ORDER BY id_cm ASC");
																	}
																	
																}else {
																	$query = mysqli_query($conn, "SELECT * FROM calon_mitra WHERE status = 2 ORDER BY id_cm ASC");
																}
																
															}else {
																$query = mysqli_query($conn, "SELECT * FROM calon_mitra WHERE status = 2 ORDER BY id_cm ASC");	
															}
                                                            while ($data = mysqli_fetch_array($query)) {
																?>
																<tr>
																	<td><?php echo $no++ ?></td>
																	<td><?php echo $data['nama_cm'] ?></td>
																	<td><?php echo $data['alamat'] ?></td>
																	<td><?php echo $data['telp'] ?></td>
																	<td><?php echo $data['sektor'] ?></td>
																	<td><?php echo $data['produk'] ?></td>
																	<td><?php echo $data['penghasilan'] ?></td>
																	<td><?php echo $data['jangka_waktu'] ?></td>
																	<td>
																		<?php if ($data["status"] == 1) { ?>
																			<span>Belum Diverifikasi</span>
																		<?php } else if ($data["status"] == 2) { ?>
																			<span>Dalam Proses</span>
																		<?php } else if ($data["status"] == 3) { ?>
																			<span>Terverifikasi</span>
																		<?php } ?>
																	</td>
																	<td><?php echo date('d F Y H:i:s', strtotime($data['tanggal'])) ?></td>
																</tr>
															<?php } ?>
														</tbody>
													</table>
												</div>
											</div>
										</div>
									</div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--end page wrapper -->
        <!--start overlay-->
        <div class="overlay toggle-icon"></div>
        <!--end overlay-->
        <!--Start Back To Top Button--> <a href="javaScript:;" class="back-to-top"><i class='bx bxs-up-arrow-alt'></i></a>
        <!--End Back To Top Button-->

        <?php include "theme-footer.php" ?>

        <!--end wrapper-->
        <!-- Bootstrap JS -->
        <script src="../assets/js/bootstrap.bundle.min.js"></script>
        <!--plugins-->
        <script src="../assets/js/jquery.min.js"></script>
        <script src="../assets/plugins/simplebar/js/simplebar.min.js"></script>
        <script src="../assets/plugins/metismenu/js/metisMenu.min.js"></script>
        <script src="../assets/plugins/perfect-scrollbar/js/perfect-scrollbar.js"></script>
        <!--app JS-->
        <script src="../assets/js/app.js"></script>
</body>

</html>