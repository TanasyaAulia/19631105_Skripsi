<footer class="page-footer">
    <p class="mb-0">Cr ©<a href="#" target="_bank">Tanasya Aulia - 19631105</a> . <?php echo date("d F Y") ?>.</p>
</footer>