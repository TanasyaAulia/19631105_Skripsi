<!--start header -->
<header>
    
    <div class="topbar d-flex align-items-center">
        <nav class="navbar navbar-expand">
            
            <div class="mobile-toggle-menu"><i class='bx bx-menu'></i>
            </div>
            <div class="top-menu ms-auto">
                
                <ul class="navbar-nav align-items-center">
                    <li class="nav-item dropdown dropdown-large">
                        <div class="dropdown-menu dropdown-menu-end">
                            <div class="header-notifications-list">
                            </div>
                        </div>
                    </li>
                    <li class="nav-item dropdown dropdown-large">
                        <div class="dropdown-menu dropdown-menu-end">
                            <div class="header-message-list">
                            </div>
                        </div>
                    </li>
                </ul>
            </div>
            <div class="user-box dropdown">
                <a class="d-flex align-items-center nav-link dropdown-toggle dropdown-toggle-nocaret" href="#"  data-bs-toggle="dropdown" aria-expanded="false">
                <?php if ($_SESSION["level"]<>'Pegawai'){ ?>
                <img src="../assets/images/users/<?php echo $row_user["foto"] ?>" class="user-img" alt="user avatar">
                <?php } ?>
                    <div class="user-info ps-3">
                        <?php if ($_SESSION["level"]<>'Pegawai'){ ?>
                            <p class="user-name mb-0"><b>Halo, <?php echo $row_user["username"] ?></b></p>
                        <?php }else{ 
                                $query_pegawai = "SELECT * FROM pegawai WHERE id_pegawai = '$id'";
                                $result_pegawai = mysqli_query($conn, $query_pegawai);
                                $row_pegawai = mysqli_fetch_assoc($result_pegawai);
                            ?>
                            <p class="user-name mb-0"><b>Halo, <?php echo $row_pegawai['nama_pegawai']; ?></b></p>
                        <?php } ?>
                        <p class="designattion mb-0">
                            <?php
                            if ($_SESSION["level"]<>'Pegawai'){
                                echo "General Service";
                            } else {
                                echo "Pegawai";
                            }
                            ?>
                        </p>
                    </div>
                </a>
                <ul class="dropdown-menu dropdown-menu-end">
                      
                    <li>
                        <a class="dropdown-item" href="profile.php"><i class="bx bx-user"></i><span>Profile</span></a>
                    </li>
                    <li>
                        <a class="dropdown-item" href="password.php"><i class="bx bx-lock"></i><span>Password</span></a>
                    </li>
                    <li>
                        <div class="dropdown-divider mb-0"></div>
                    </li>
                    <li><a class="dropdown-item" href="logout.php" onClick="return confirm('Apakah Anda Yakin Ingin Logout ?')"><i class='bx bx-log-out-circle'></i><span>Logout</span></a>
                    </li>
                </ul>
            </div>
        </nav>
    </div>
</header>
<!--end header -->