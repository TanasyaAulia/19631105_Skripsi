<!--sidebar wrapper -->
<div class="sidebar-wrapper" data-simplebar="true">
    <div class="sidebar-header">
        <div>
        <a href="index.php">
            <img src="../assets/images/logo2.png" class="logo-icon" alt="logo icon">
            </a>
        </div>
        <div>
        <a href="index.php">
            <h5 class="logo-text">Angkasa Pura</h5>
            </a>
        </div>
        <div class="toggle-icon ms-auto"><i class='bx bx-arrow-to-left'></i>
        </div>
    </div>
    <!--navigation-->
    <ul class="metismenu" id="menu">
        <li>
            <a href="index.php">
                <div class="parent-icon"><i class='bx bx-home-circle'></i></div>
                <div class="menu-title">Dashboard</div>
            </a>
        </li>
        <?php if ($_SESSION["level"]<>'Pegawai'){ ?>
            
        <li>
            <a href="user.php">
                <div class="parent-icon"><i class='bx bx-group'></i></div>
                <div class="menu-title">Data User</div>
            </a>
        </li>
        <li>
            <a href="pegawai.php">
                <div class="parent-icon"><i class='lni lni-users'></i></div>
                <div class="menu-title">Data Pegawai</div>
            </a>
        </li>
        <li>
            <a href="bagian.php">
                <div class="parent-icon"><i class='bx bx-extension'></i></div>
                <div class="menu-title">Bagian</div>
            </a>
        </li>
        <?php } ?>
        <li>
            <a href="javascript:;" class="has-arrow">
                <div class="parent-icon"><i class='bx bx-spreadsheet'></i></div>
                <div class="menu-title">Data</div>
            </a>
            <ul>
                <li> <a href="pengunjung.php"><i class="bx bx-right-arrow-alt"></i>Pengunjung</a></li>
        <?php if ($_SESSION["level"]<>'Pegawai'){ ?>
                <li> <a href="penawaran.php"><i class="bx bx-right-arrow-alt"></i>Penawaran</a></li>
                <li> <a href="calon_mitra.php"><i class="bx bx-right-arrow-alt"></i>Calon Mitra</a></li>
        <?php } ?>
                <li> <a href="berkas.php"><i class="bx bx-right-arrow-alt"></i>Berkas/Dokumen</a></li>
                <li> <a href="paket.php"><i class="bx bx-right-arrow-alt"></i>Paket Masuk</a></li>
            </ul>
        </li>
        <li>
            <a href="javascript:;" class="has-arrow">
                <div class="parent-icon"><i class="bx bx-task"></i></div>
                <div class="menu-title">Laporan</div>
            </a>
            <ul>
            <li><a href="laporan_pengunjung.php"><i class="bx bx-right-arrow-alt"></i>Pengunjung </a></li>
            <!-- <li><a href="pengunjung_print.php"><i class="bx bx-right-arrow-alt"></i>Pengunjung </a></li> -->
                <li> <a href="laporan_pengunjung2.php"><i class="bx bx-right-arrow-alt"></i>Pengunjung (Belum Ditemui)</a></li>
                <!-- <li> <a href="pengunjung_print2.php"><i class="bx bx-right-arrow-alt"></i>Pengunjung (Belum Ditemui)</a></li> -->
        <!-- <?php if ($_SESSION["level"]<>'Pegawai'){ ?> -->
                <!-- <li> <a href="penawaran_print.php"><i class="bx bx-right-arrow-alt"></i>Penawaran</a></li> -->
                <li> <a href="laporan_penawaran.php"><i class="bx bx-right-arrow-alt"></i>Penawaran</a></li>
                <!-- <li> <a href="cm_print.php"><i class="bx bx-right-arrow-alt"></i>Calon Mitra</a></li> -->
                <li> <a href="laporan_cm.php"><i class="bx bx-right-arrow-alt"></i>Calon Mitra</a></li>
                <li> <a href="laporan_cm2.php"><i class="bx bx-right-arrow-alt"></i>Calon Mitra (Proses Verifikasi)</a></li>
                <!-- <li> <a href="cm_print2.php"><i class="bx bx-right-arrow-alt"></i>Calon Mitra (Proses Verifikasi)</a></li> -->
        <?php } ?>
                <li> <a href="laporan_berkas.php"><i class="bx bx-right-arrow-alt"></i>Berkas/Dokumen</a></li>
                <!-- <li> <a href="berkas_print.php"><i class="bx bx-right-arrow-alt"></i>Berkas/Dokumen</a></li> -->
                <li> <a href="laporan_berkas2.php"><i class="bx bx-right-arrow-alt"></i>Berkas/Dokumen (Belum Diverifikasi)</a></li>
                <!-- <li> <a href="berkas_print2.php"><i class="bx bx-right-arrow-alt"></i>Berkas/Dokumen (Belum Diverifikasi)</a></li> -->
                <li> <a href="laporan_paket.php"><i class="bx bx-right-arrow-alt"></i>Paket Masuk</a></li>
                <!-- <li> <a href="paket_print.php"><i class="bx bx-right-arrow-alt"></i>Paket Masuk</a></li> -->
            </ul>
        
        <?php if ($_SESSION["level"]<>'Pegawai'){ ?>
        <li class="menu-label">Personalisasi</li>
        <li>
            <a href="profile.php">
                <div class="parent-icon"><i class='bx bx-user'></i></div>
                <div class="menu-title">Profile</div>
            </a>
        </li>
        <li>
            <a href="password.php">
                <div class="parent-icon"><i class='bx bx-lock'></i></div>
                <div class="menu-title">Password</div>
            </a>
        </li>
        <li>
            <a href="tema.php">
                <div class="parent-icon"><i class='bx bx-category'></i></div>
                <div class="menu-title">Tema</div>
            </a>
        </li>
        <?php } ?>
        <li>
            <a href="logout.php" onClick="return confirm('Apakah Anda Yakin Ingin Logout?')">
                <div class="parent-icon"><i class='bx bx-log-out-circle'></i></div>
                <div class="menu-title" title="logout" >Logout</div>
            </a>
        </li>
    </ul>
    <!--end navigation-->
</div>
<!--end sidebar wrapper -->