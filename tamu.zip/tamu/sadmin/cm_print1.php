<!-- <link rel="stylesheet" href="../css/sb-admin-2.min.css"> -->

<style>
* {
  font-family: Arial, Helvetica, sans-serif;
}

</style>
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!--favicon-->
    <link rel="icon" href="../assets/images/logo2.png" type="image/png" />
<title>Laporan Detail Data Calon Mitra Binaan</title>
</head>
<img src="../assets\images\kop1.png" align=left height="150" width="200">
<img src="../assets/images/kop2.png" align=right height="150" width="200">
<br> <br>
<br> <br>
<br> <br>
<h3 align="center">Laporan Detail Data Calon Mitra Binaan</h3>
<div class="table-responsive mt-2">
  <table border="1" width="70%" align="center" cellpadding="8">
    <tbody>
      <?php
      include '../koneksi.php';
      $id = $_GET['id'];
      $query = mysqli_query($conn, "SELECT * FROM calon_mitra WHERE id_cm = '$id'");
      while ($data = mysqli_fetch_array($query)) { ?>
      <tr>
        <td width=5%>No.</td>
        <td width=5%> : <?php echo $data['id_cm'] ?></td>
      </tr>
      <tr>
        <td>Nama Lengkap </td>
        <td> : <?php echo $data['nama_cm'] ?></td>
      </tr>
      <tr>
        <td>Alamat</td>
        <td> : <?php echo $data['alamat'] ?></td>
      </tr>
      <tr>
        <td>No. Telepon</td>
        <td> : <?php echo $data['telp'] ?></td>
      </tr>
      <tr>
        <td>Sektor</td>
        <td> : <?php echo $data['sektor'] ?></td>
      </tr>
      <tr>
        <td>Produk</td>
        <td> : <?php echo $data['produk'] ?></td>
      </tr>
      <tr>
        <td>Penghasilan</td>
        <td> : <?php echo $data['telp'] ?></td>
      </tr>
     
      <tr>
        <td>Jangka Waktu</td>
        <td> : <?php echo $data['jangka_waktu'] ?></td>
      </tr>
     
      <tr>
        <td>Tanggal</td>
        <td> : <?php echo date('d F Y H:i:s') ?></td>
      </tr>
      <tr>
        <td>Status</td>
        <td> :  <?php if ($data["status"] == 1) { ?>
                                                    <span> <b>Belum Diverifikasi </b></span>
                                                <?php } else if ($data["status"] == 2) { ?>
                                                    <span ><b>Dalam Proses</b> </span>
                                                <?php } else if ($data["status"] == 3) { ?>
                                                    <span><b>Terverifikasi </b> </span>
                                                <?php } ?></td>
      </tr>
     


      <?php
                        }
                        ?>
      
    </tbody>
  </table>  <br>
    <br>
    <br>
    <br>
    <br>
    <div style="text-align:center">

        <p>Banjarbaru, <?php echo date('d F Y'); ?></p>
        
        <p>
                                            <?php 
                                            
                                               $query = mysqli_query($conn, "SELECT * FROM calon_mitra WHERE id_cm = '$id'");
                                              
                                               while ($data = mysqli_fetch_array($query)) 
                     
                                               $kode = "Laporan Detail Data Calon Mitra "."a.n ".$data['nama_cm']." telah Diterima oleh "."Ahmad Zulfian Noor, "."Kepala Stakeholder Relation";
                                            require_once('../assets/phpqrcode/qrlib.php');
                                            QRcode::png("$kode","Laporan Detail Data Calon Mitra".$data.".png","M", 4,4);
                                            
                                            ?>
                                            <img src="Laporan Detail Data Calon Mitra<?php echo $data?>.png" alt=""></p>
        <p><u><b>Ahmad Zulfian Noor</b></u> </p>
        <p><b>NIP. 9776074-A </b></p>
    </div>
</div>

<script>
window.print();
</script>