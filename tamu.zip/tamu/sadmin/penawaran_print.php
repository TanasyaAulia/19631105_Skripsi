<!-- <link rel="stylesheet" href="../css/sb-admin-2.min.css"> -->
<style>
* {
  font-family: Arial, Helvetica, sans-serif, center;
}

table {
  border-collapse: collapse;
  border-color: black;
}
</style>
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!--favicon-->
    <link rel="icon" href="../assets/images/logo2.png" type="image/png" />
    
    <title>Laporan Data Penawaran </title>
</head>
<img src="../assets\images\kop1.png" align=left height="150" width="200">
<img src="../assets/images/kop2.png" align=right height="150" width="200">
<br> <br>
<br> <br>
<br> <br>

<h2 align="center">Laporan Data Penawaran</h2>
<div class="table-responsive mt-3">
  <table border="3" width="100%" align="center" cellpadding="8">
    <thead>
      <tr>
        <th width="2%">No.</th>
        <th width="10%">Nama Lengkap</th>
        <th width="15%">Alamat</th>
        <th width="15%">Instansi</th>
        <th width="10%">No. Telepon</th>
        <th width="15%">Produk/Jasa yang Ditawarkan</th>
        <th width="10%">Tanggal</th>
      </tr>
    </thead>

    <tbody>
    <?php
              include '../koneksi.php';
              
              if(isset($_GET['tipe'])) {
																	
                if($_GET['tipe'] == "pertanggal") {
                  $from = $_GET['from'];
                  $to = $_GET['to']; 
                  
                  $query = mysqli_query($conn, "SELECT * FROM penawaran WHERE DATE(tanggal) BETWEEN '$from' AND '$to' ORDER BY id_penawaran ASC");
                }else if($_GET['tipe'] == "perbulan") {
                  $bulan = $_GET['bulan'];
                  $tahun = $_GET['tahun'];
                  
                  $query = mysqli_query($conn, "SELECT * FROM penawaran WHERE DATE(tanggal) LIKE '$tahun-$bulan%' ORDER BY id_penawaran ASC");
                }else if($_GET['tipe'] == "pertahun") {
                  $tahun = $_GET['tahun'];

                  $query = mysqli_query($conn, "SELECT * FROM penawaran WHERE tanggal LIKE '$tahun%' ORDER BY id_penawaran ASC");
                }else {
                  $query = mysqli_query($conn, "SELECT * FROM penawaran ORDER BY id_penawaran ASC");
                }
                
              }else {
                $query = mysqli_query($conn, "SELECT * FROM penawaran ORDER BY id_penawaran ASC");
              }
              while ($data = mysqli_fetch_array($query)) { 
                $id_penawaran= $data['id_penawaran'];
                ?>
      <tr>
        <td><?php echo $data['id_penawaran']; ?></td>
        <td><?php echo $data['nama']; ?></td>
        <td><?php echo $data['alamat']; ?></td>
        <td><?php echo $data['instansi']; ?></td>
        <td><?php echo $data['telp']; ?></td>
        <td><?php echo $data['produk_jasa']; ?></td>
        <td><?php echo date('d F Y H:i:s') ;?></td>
       
      </tr>
      <?php
      }
      ?>
    </tbody>
  </table>
  <br>
    <br>
    <br>
    <br>
    <br>

    <div style="text-align:center">

        <p>Banjarbaru, <?php echo date('d F Y'); ?></p>
        <p>
                                            <?php 
                                               $query = "SELECT * FROM penawaran ORDER BY id_penawaran ASC";
                                               $result = mysqli_query($conn, $query);
                                               while ($data = mysqli_fetch_array($result))
                     
                                               $uri_path = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
                                               $uri_segments = explode('/', $uri_path);
                                               $baseURL = 'http://'.getHostByName(getHostName()).'/'.$_SERVER["REQUEST_URI"];
                                               
                                               $directoryURI = $_SERVER['REQUEST_URI'];
                                               $parseURI = parse_url($directoryURI, PHP_URL_PATH);
                                               $componentsURI = explode('/', $parseURI);
                                               $pathURI = $componentsURI[2];

                                            $kode = $baseURL;
                                            require_once('../assets/phpqrcode/qrlib.php');
                                            QRcode::png("$kode","Laporan".$data.".png","M", 4,4);
                                            
                                            ?>
                                            <img src="Laporan<?php echo $data?>.png" alt=""></p>
        <p><b>General Manager</b></p>
    </div>
</div>

<script>
window.print();

</script>