<!-- <link rel="stylesheet" href="../css/sb-admin-2.min.css"> -->

<style>
* {
  font-family: Arial, Helvetica, sans-serif;
}

</style>
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!--favicon-->
    <link rel="icon" href="../assets/images/logo2.png" type="image/png" />
<title>Laporan Detail Data Berkas</title>
</head>
<img src="../assets\images\kop1.png" align=left height="150" width="200">
<img src="../assets/images/kop2.png" align=right height="150" width="200">
<br> <br>
<br> <br>
<br> <br>
<h3 align="center">Laporan Detail Data Berkas</h3>
<div class="table-responsive mt-2">
  <table border="1" width="70%" align="center" cellpadding="8">
    <tbody>
      <?php
      include '../koneksi.php';
      $id = $_GET['id'];
      $query = mysqli_query($conn, "SELECT * FROM berkas WHERE id_berkas = '$id'");
      while ($data = mysqli_fetch_array($query)) { ?>
      <tr>
        <td width=5%>No.</td>
        <td width=5%> : <?php echo $data['id_berkas'] ?></td>
      </tr>
      
      <tr>
        <td>Nomor Surat</td>
        <td> : <?php echo $data['no_surat'] ?></td>
      </tr>
        
      <tr>
        <td>Instansi</td>
        <td> : <?php echo $data['instansi'] ?></td>
      </tr>
      <tr>
        <td>Nama Lengkap </td>
        <td> : <?php echo $data['nama'] ?></td>
      </tr>
      <tr>
        <td>Alamat</td>
        <td> : <?php echo $data['alamat'] ?></td>
      </tr>
    
      <tr>
        <td>No. Telepon</td>
        <td> : <?php echo $data['telp'] ?></td>
      </tr>
     
      <tr>
        <td>Perihal</td>
        <td> : <?php echo $data['perihal'] ?></td>
      </tr>
     
      <tr>
        <td>Tanggal</td>
        <td> : <?php echo date('d F Y H:i:s') ?></td>
      </tr>
      
      <tr>
        <td>Status</td>
        <td> :  <?php if ($data["status"] == 1) { ?>
                                                    <span> <b>Belum Diverifikasi </b></span>
                                                <?php } else if ($data["status"] == 2) { ?>
                                                    <span ><b>Dalam Proses</b> </span>
                                                <?php } else if ($data["status"] == 3) { ?>
                                                    <span><b>Terverifikasi </b> </span>
                                                <?php } ?></td>
      </tr>
      <tr>
        <td>Bagian</td>
        <td> : <?php
                         $id = $_GET['id'];
                         $query = mysqli_query($conn, "SELECT * FROM berkas p, bagian s WHERE id_berkas= $id AND s.id_bagian=p.id_bagian ");
                         while ($data_bagian = mysqli_fetch_array($query)) { ?>
                        <b><?php echo $data_bagian['nama_bagian']; ?></b> 
                      </td>
      </tr>


      <?php
                        }
                        ?>
        <?php
      }
      ?>
    </tbody>
  </table>  <br>
    <br>
    <br>
    <br>
    <br>
    <div style="text-align:center">

        <p>Banjarbaru, <?php echo date('d F Y'); ?></p>
        <p>
                                            <?php 
                                             $id = $_GET['id'];
                                             $query = mysqli_query($conn, "SELECT * FROM berkas p, bagian s WHERE id_berkas= $id AND s.id_bagian=p.id_bagian ");
                                              while ($data_bagian = mysqli_fetch_array($query)) 
                     
                                            $kode = "Laporan Detail Data Berkas "."a.n ".$data_bagian['nama']." "." telah Diterima oleh ".$data_bagian['nama_bagian']." dengan Perihal ".$data_bagian['perihal']."";
                                            require_once('../assets/phpqrcode/qrlib.php');
                                            QRcode::png("$kode","kode".$id.".png","M", 4,4);
                                            
                                            ?>
                                            <img src="kode<?php echo $id?>.png" alt=""></p>
        <p><?php
                        
                         $id = $_GET['id'];
                         $query = mysqli_query($conn, "SELECT * FROM berkas p, bagian s WHERE id_berkas= $id AND s.id_bagian=p.id_bagian ");
                         while ($data_bagian = mysqli_fetch_array($query)) { ?>

                        <b><?php echo $data_bagian['nama_bagian']; ?></b></p>
                        <?php
      }
      ?>
    </div>
</div>

<script>
window.print();
</script>