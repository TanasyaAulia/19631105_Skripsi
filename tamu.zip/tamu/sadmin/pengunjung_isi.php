<?php
session_start();


include "../koneksi.php";


if (isset($_POST["submit"])) {

    $status = htmlspecialchars($_POST["status"]);
    $nama_tamu = htmlspecialchars($_POST["nama_tamu"]);
    $alamat = htmlspecialchars($_POST["alamat"]);
    $telp = htmlspecialchars($_POST["telp"]);
    $id_pegawai = htmlspecialchars($_POST["id_pegawai"]);
    $tujuan = htmlspecialchars($_POST["tujuan"]);
    $tanggal = htmlspecialchars($_POST["tanggal"]);
  
    $query = "INSERT INTO pengunjung VALUES (NULL, '$status','$nama_tamu','$alamat','$telp','$id_pegawai','$tujuan','$tanggal')";
    $simpan = mysqli_query($conn, $query);

    if ($simpan) {
      unset($_SESSION);
      session_destroy();
        echo "<script>
            alert('Data BERHASIL Disimpan...!');
            document.location.href = '../index.php';
            </script>";
    } else {
        echo "<script>
            alert('Data GAGAL Disimpan..!');
            history.go(-1);
            </script>";
    }
}
?>
<!doctype html>
<html lang="en" class="<?php echo $row_user["theme"] ?>">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!--favicon-->
    <link rel="icon" href="../assets/images/logo2.png" type="image/png" />
    <!--plugins-->
    <link href="../assets/plugins/simplebar/css/simplebar.css" rel="stylesheet" />
    <link href="../assets/plugins/perfect-scrollbar/css/perfect-scrollbar.css" rel="stylesheet" />
    <link href="../assets/plugins/metismenu/css/metisMenu.min.css" rel="stylesheet" />
    <!-- loader-->
    <link href="../assets/css/pace.min.css" rel="stylesheet" />
    <script src="../assets/js/pace.min.js"></script>
    <!-- Bootstrap CSS -->
    <link href="../assets/css/bootstrap.min.css" rel="stylesheet">
    <link href="../assets/css/app.css" rel="stylesheet">
    <link href="../assets/css/icons.css" rel="stylesheet">
    <!-- Theme Style CSS -->
    <link rel="stylesheet" href="../assets/css/dark-theme.css" />
    <link rel="stylesheet" href="../assets/css/semi-dark.css" />
    <link rel="stylesheet" href="../assets/css/header-colors.css" />
    <title>Isi Data Pengunjung</title>
</head>

<body class="bg-login">
  <div class="container">
    <div class="row justify-content-center">
      <div class="col-xl-6 col-lg-6 col-md-9">
          <div class="card-body p-0">
            <div class="row">

            <div class="card">
                            <div class="card-body">
                                <div class="border p-4 rounded">
                  <div class="text-center">
                  <img src="../assets/images/logoaja.png" width="300px" class="mb-0">
                  
                  <div class="login-separater text-center mb-4"> <span>Silahkan Isi Data Kunjungan Anda Dibawah Ini dengan <b>Lengkap</b> dan <b>Benar !</b></span>
                    <hr>
                    <br>
                  </div>
                  </div>
                                <form class="row g-3" method="POST" target="">
                                <?php if (isset($_SESSION['nama_tamu'])){ ?>
                                    <div class="col-12">
                                        <label for="nama_tamu" class="form-label">Nama :</label>
                                        <input type="text" class="form-control" name="nama_tamu" id="nama_tamu" placeholder="Nama Lengkap" required value="<?= $_SESSION['nama_tamu']; ?>">
                                    </div>

                                    <div class="col-12">
                                        <label for="alamat" class="form-label">Alamat :</label>
                                        <input type="text" class="form-control" name="alamat" id="alamat" placeholder="Alamat Lengkap" required  value="<?= $_SESSION['alamat']; ?>">
                                    </div>

                                    <div class="col-6">
                                        <label for="telp" class="form-label">Telepon :</label>
                                        <input type="number" class="form-control" name="telp" id="telp" placeholder="No. Telepon Aktif" required  value="<?= $_SESSION['telp']; ?>">
                                    </div>
                                    <?php }else{ ?>
                                    <div class="col-12">
                                        <label for="nama_tamu" class="form-label">Nama :</label>
                                        <input type="text" class="form-control" name="nama_tamu" id="nama_tamu" placeholder="Nama Lengkap" required>
                                    </div>

                                    <div class="col-12">
                                        <label for="alamat" class="form-label">Alamat :</label>
                                        <input type="text" class="form-control" name="alamat" id="alamat" placeholder="Alamat Lengkap" required>
                                    </div>

                                    <div class="col-6">
                                        <label for="telp" class="form-label">Telepon :</label>
                                        <input type="number" class="form-control" name="telp" id="telp" placeholder="No. Telepon Aktif" required>
                                    </div>
                                    <?php } ?>


                                    <div class="col-6">
                                        <label for="id_pegawai" class="form-label">Pegawai yang Dikunjungi :</label>
                                        <select name="id_pegawai" id="id_pegawai" class="form-select" required>
                                            <option value="">Pilih...</option>
                                            <?php
                                            $query_pegawai = "SELECT * FROM pegawai";
                                            $result_pegawai = mysqli_query($conn, $query_pegawai);
                                            while ($row_pegawai = mysqli_fetch_assoc($result_pegawai)) {;
                                            ?>
                                                <option value="<?php echo $row_pegawai["id_pegawai"] ?>"><?php echo $row_pegawai["nama_pegawai"] ?></option>
                                            <?php } ?>
                                        </select>
                                    </div>
                                    <div class="col-12">
                                        <label for="tujuan" class="form-label">Tujuan :</label>
                                        <input type="text" class="form-control" name="tujuan" id="tujuan" placeholder="Tujuan Kunjungan" required>
                                    </div>
                                    
                                    <div class="login-separater text-center mb-4"> <span>Jika Data Sudah Benar, Klik Tombol <b>Simpan</b> Dibawah Ini !</span>
                    <hr>
                    <br>
                                    <input type="hidden" name="tanggal" value="<?php echo date('Y-m-d H:i:s') ?>">
                                    <input type="hidden" name="status" value="1">


                                    <div class="col-12">
                                        <button type="submit" class="btn btn-success px-3" name="submit"><i class="bx bx-save"></i>Simpan</button>
                                        <button type="button" class="btn btn-secondary px-3" onclick="self.history.back()"><i class="bx bx-arrow-back"></i>Cancel </button>
                                    </div>
                             <footer class="sticky-footer bg-white">
        <div class="container">
            <div class="copyright text-center">
                <span>
                    <a href="index.php"><?= date('j F Y') ?></a> &copy; Angkasa Pura 1 </span>
            </div>
        </div>
    </footer>
                </form>


                </div>
                
              </div>
              
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <script src="../vendor/jquery/jquery.min.js"></script>
  <script src="../vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="../vendor/jquery-easing/jquery.easing.min.js"></script>
  <script src="../js/sb-admin-2.min.js"></script>

  <script>
    window.setTimeout(function() {
      $(".alert").fadeTo(500, 0).slideUp(500, function() {
        $(this).remove();
      });
    }, 5000);
  </script>

</body>

</html>