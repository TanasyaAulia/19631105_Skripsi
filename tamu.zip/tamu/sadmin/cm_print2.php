<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="../assets/images/logo2.png" type="image/png" />
    <title>Laporan Data Calon Mitra Binaan (Proses Verifikasi)</title>
    <style>
        * {
            font-family: Arial, Helvetica, sans-serif, center;
        }

        table {
            border-collapse: collapse;
            border-color: black;
        }
    </style>
</head>

<body>
    <img src="../assets\images\kop1.png" align="left" height="150" width="200">
    <img src="../assets/images/kop2.png" align="right" height="150" width="200">
    <br> <br>
    <br> <br>
    <br> <br>
    <h2 align="center">Laporan Data Calon Mitra Binaan (Proses Verifikasi)</h2>
    <div class="table-responsive mt-3">
        <table border="3" width="100%" align="center" cellpadding="8">
            <thead>
                <tr>
                    <th width="2%">No.</th>
                    <th width="15%">Nama Lengkap</th>
                    <th width="20%">Alamat</th>
                    <th width="10%">No. Telepon</th>
                    <th width="20%">Sektor</th>
                    <th width="15%">Produk</th>
                    <th width="10%">Status</th>
                </tr>
            </thead>

            <tbody>
                <?php
                include '../koneksi.php';

                if(isset($_GET['tipe'])) {
																	
                    if($_GET['tipe'] == "pertanggal") {
                        $from = $_GET['from'];
                        $to = $_GET['to']; 
                        
                        $query = mysqli_query($conn, "SELECT * FROM calon_mitra WHERE DATE(tanggal) BETWEEN '$from' AND '$to' AND status = 2 ORDER BY id_cm ASC");
                    }else if($_GET['tipe'] == "perbulan") {
                        $bulan = $_GET['bulan'];
                        $tahun = $_GET['tahun'];
                        
                        $query = mysqli_query($conn, "SELECT * FROM calon_mitra WHERE DATE(tanggal) LIKE '$tahun-$bulan%' AND status = 2 ORDER BY id_cm ASC");
                    }else if($_GET['tipe'] == "pertahun") {
                        $tahun = $_GET['tahun'];

                        $query = mysqli_query($conn, "SELECT * FROM calon_mitra WHERE tanggal LIKE '$tahun%' AND status = 2 ORDER BY id_cm ASC");
                    }else {
                        $query = mysqli_query($conn, "SELECT * FROM calon_mitra WHERE status = 2 ORDER BY id_cm ASC");
                    }
                    
                }else {
                    $query = mysqli_query($conn, "SELECT * FROM calon_mitra WHERE status = 2 ORDER BY id_cm ASC");
                }
                $no = 1;
                while ($data = mysqli_fetch_array($query)) {
                ?>
                    <tr>
                        <td><?php echo $no++ ?></td>
                        <td><?php echo $data['nama_cm'] ?></td>
                        <td><?php echo $data['alamat'] ?></td>
                        <td><?php echo $data['telp'] ?></td>
                        <td><?php echo $data['sektor'] ?></td>
                        <td><?php echo $data['produk'] ?></td>
                        <td>
                            <?php if ($data['status'] == 1) { ?>
                                <span>Belum Diverifikasi</span>
                            <?php } else if ($data['status'] == 2) { ?>
                                <span>Proses Verifikasi</span>
                            <?php } else if ($data['status'] == 3) { ?>
                                <span>Terverifikasi</span>
                            <?php } ?>
                        </td>
                    </tr>
                <?php
                }
                ?>

            </tbody>
        </table>
        <br>
        <br>
        <br>
        <br>
        <br>
        <div style="text-align:center">

            <p>Banjarbaru, <?php echo date('d F Y'); ?></p>
            <p>
                                            <?php 
                                            
                                               $query = mysqli_query($conn, "SELECT * FROM calon_mitra WHERE status = 2");
                                              
                                               while ($data = mysqli_fetch_array($query)) 
                     
                                               $uri_path = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
                                               $uri_segments = explode('/', $uri_path);
                                               $baseURL = 'http://'.getHostByName(getHostName()).'/'.$_SERVER["REQUEST_URI"];
                                               
                                               $directoryURI = $_SERVER['REQUEST_URI'];
                                               $parseURI = parse_url($directoryURI, PHP_URL_PATH);
                                               $componentsURI = explode('/', $parseURI);
                                               $pathURI = $componentsURI[2];

                                            $kode = $baseURL;
                                            require_once('../assets/phpqrcode/qrlib.php');
                                            QRcode::png("$kode","Laporan".$data.".png","M", 4,4);
                                            
                                            ?>
                                            <img src="Laporan<?php echo $data?>.png" alt=""></p>
            <p><u><b>Ahmad Zulfian Noor</b></u> </p>
        <p><b>NIP. 9776074-A </b></p>
        </div>
    </div>

    <script>
        window.print();
    </script>
</body>

</html>
