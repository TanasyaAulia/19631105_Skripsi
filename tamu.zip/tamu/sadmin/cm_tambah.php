<?php

session_start();

if ($_SESSION["level"] == 2 or $_SESSION["level"] == 3 or $_SESSION["level"] == 4) {
    header("Location: logout.php");
    exit;
}

if (!isset($_SESSION["login"])) {
    header("Location: ../index.php");
    exit;
}

include "../koneksi.php";

$id = $_SESSION["id"];

$query_user = "SELECT * FROM user WHERE id = '$id'";
$result_user = mysqli_query($conn, $query_user);
$row_user = mysqli_fetch_assoc($result_user);

if (isset($_POST["submit"])) {

    $tanggal = htmlspecialchars($_POST["tanggal"]);
    $status = htmlspecialchars($_POST["status"]);
    $nama_cm = htmlspecialchars($_POST["nama_cm"]);
    $alamat = htmlspecialchars($_POST["alamat"]);
    $telp = htmlspecialchars($_POST["telp"]);
    $sektor = htmlspecialchars($_POST["sektor"]);
    $produk = htmlspecialchars($_POST["produk"]);
    $penghasilan = htmlspecialchars($_POST["penghasilan"]);
    $jangka_waktu = htmlspecialchars($_POST["jangka_waktu"]);

    $query = "INSERT INTO calon_mitra VALUES (NULL, '$tanggal','$status','$nama_cm','$alamat','$telp','$sektor','$produk','$penghasilan','$jangka_waktu')";
    $simpan = mysqli_query($conn, $query);

    if ($simpan) {
        echo "<script>
            alert('Data BERHASIL Disimpan...!');
            document.location.href = 'calon_mitra.php';
            </script>";
    } else {
        echo "<script>
            alert('Data GAGAL Disimpan..!');
            history.go(-1);
            </script>";
    }
}

?>
<!doctype html>
<html lang="en" class="<?php echo $row_user["theme"] ?>">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!--favicon-->
    <link rel="icon" href="../assets/images/logo2.png" type="image/png" />
    <!--plugins-->
    <link href="../assets/plugins/simplebar/css/simplebar.css" rel="stylesheet" />
    <link href="../assets/plugins/perfect-scrollbar/css/perfect-scrollbar.css" rel="stylesheet" />
    <link href="../assets/plugins/metismenu/css/metisMenu.min.css" rel="stylesheet" />
    <!-- loader-->
    <link href="../assets/css/pace.min.css" rel="stylesheet" />
    <script src="../assets/js/pace.min.js"></script>
    <!-- Bootstrap CSS -->
    <link href="../assets/css/bootstrap.min.css" rel="stylesheet">
    <link href="../assets/css/app.css" rel="stylesheet">
    <link href="../assets/css/icons.css" rel="stylesheet">
    <!-- Theme Style CSS -->
    <link rel="stylesheet" href="../assets/css/dark-theme.css" />
    <link rel="stylesheet" href="../assets/css/semi-dark.css" />
    <link rel="stylesheet" href="../assets/css/header-colors.css" />
    <title>Tambah Data Calon Mitra</title>
</head>

<body>
    <!--wrapper-->
    <div class="wrapper">

        <?php include "theme-sidebar.php" ?>

        <?php include "theme-header.php" ?>

        <!--start page wrapper -->
        <div class="page-wrapper">
            <div class="page-content">
                <!--breadcrumb-->
                <div class="page-breadcrumb d-none d-sm-flex align-items-center mb-3">
                    <div class="ps-3">
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb mb-0 p-0">
                                <li class="breadcrumb-item"><a href="index.php"><i class="bx bx-home-alt"></i></a></li>
                                <li class="breadcrumb-item"><a href="calon_mitra.php">Data Calon Mitra</a></li>
                                <li class="breadcrumb-item active" aria-current="page">Tambah Data Calon Mitra</li>
                            </ol>
                        </nav>
                    </div>
                </div>
                <!--end breadcrumb-->
                <div class="row">
                    <div class="col-xl-10 mx-auto">
                        <br>
                        <div class="card border-top border-0 border-4 border-primary">
                            <div class="card-body px-5 pb-5">
                                <div class="card-title d-flex align-items-center">
                                    <div><i class="bx bx-plus me-1 font-22 text-primary"></i>
                                    </div>
                                    <h5 class="mb-0 text-primary">Tambah Data Calon Mitra</h5>
                                </div>
                                <hr>
                                <form class="row g-3" method="POST" target="">
                                    <div class="col-12">
                                        <label for="nama_cm" class="form-label">Nama :</label>
                                        <input type="text" class="form-control" name="nama_cm" id="nama_cm" placeholder="Nama Lengkap Calon Mitra" required>
                                    </div>
                                    <div class="col-12">
                                        <label for="alamat" class="form-label">Alamat :</label>
                                        <input type="text" class="form-control" name="alamat" id="alamat" placeholder="Alamat Lengkap" required>
                                    </div>
                                    <div class="col-3">
                                        <label for="telp" class="form-label">No. Telepon :</label>
                                        <input type="number" class="form-control" name="telp" id="telp" placeholder="No. Telepon Aktif" required>
                                    </div>
                                  
                                    <div class="col-12">
                        <label for="sektor"class="col-sm-2 col-form-label">Sektor Usaha : </label>
                        <div class="col-sm-6">
                        <select class="form-select" id="sektor" name="sektor" style="margin-bottom:10px;">
                            <option selected>- Pilih -</option>
                            <option value="Industri">Industri</option>
                            <option value="Perdagangan">Perdagangan</option>
                            <option value="Pertanian">Pertanian</option>
                            <option value="Peternakan">Peternakan</option>
                            <option value="Perkebunan">Perkebunan</option>
                            <option value="Perikanan">Perikanan</option>
                            <option value="Jasa">Jasa</option>
                            <option value="Lainnya">Lainnya</option>

                        </select>
                        </div>
                    </div>

                                    <div class="col-12">
                                        <label for="produk" class="form-label">Produk :</label>
                                        <input type="text" class="form-control" name="produk" id="produk" placeholder="Produk" required>
                                    </div>
                                    <div class="col-6">
            <label for="penghasilan" class="col-sm-6 col-form-label">Penghasilan per Bulan :</label>
            <div class="col-sm-12">
                        <select class="form-select" id="penghasilan" name="penghasilan" aria-label="Default select example">
                            <option selected>- Pilih -</option>
                            <option value="Rp500.000 - Rp1.000.000">Rp500.000 - Rp1.000.000</option>
                            <option value="Rp1.000.000 - Rp2.000.000">Rp1.000.000 - Rp2.000.000</option>
                            <option value="Rp2.000.000 - Rp4.000.000">Rp2.000.000 - Rp4.000.000</option>
                            <option value="Rp4.000.000 - Rp6.000.000">Rp4.000.000 - Rp6.000.000</option>
                            <option value=">Rp6.000.000">>Rp6.000.000</option>

                        </select>
                    </div>
          </div> 
          <div class="col-6">
            <label for="jangka_waktu" class="col-sm-6 col-form-label">Jangka Waktu Mitra Binaan : </label>
            <div class="col-sm-12">
                        <select class="form-select" id="jangka_waktu" name="jangka_waktu" aria-label="Default select example">
                            <option selected>- Pilih -</option>
                            <option value="2 Bulan">2 Bulan</option>
                            <option value="6 Bulan">6 Bulan</option>
                            <option value="1 Tahun">1 Tahun</option>
                            <option value="5 Tahun">5 Tahun</option>
                            <option value=">>5 Tahun">>5 Tahun</option>

                        </select>
                    </div>
          </div>
          <div class="col-12">
                                        <label class="form-label">Status :</label><br>
                                        <div class="form-check form-check-inline">
                                            <input class="form-check-input" type="radio" name="status" id="inlineRadio1" value="1">
                                            <label class="form-check-label" for="inlineRadio1">Belum Diverifikasi</label>
                                        </div>
                                        <div class="form-check form-check-inline">
                                            <input class="form-check-input" type="radio" name="status" id="inlineRadio2" value="2">
                                            <label class="form-check-label" for="inlineRadio2">Dalam Proses</label>
                                        </div> 
                                        <div class="form-check form-check-inline">
                                            <input class="form-check-input" type="radio" name="status" id="inlineRadio3" value="3">
                                            <label class="form-check-label" for="inlineRadio3">Terverifikasi</label>
                                        </div>
                                       
                                    </div>

                                    <input type="hidden" name="tanggal" value="<?php echo date('Y-m-d H:i:s') ?>">
                                    <div class="col-12">
                                        <button type="submit" class="btn btn-primary px-5" name="submit">Simpan</button>
                                        <button type="button" class="btn btn-secondary px-5" onclick="self.history.back()">Cancel</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--end page wrapper -->
        <!--start overlay-->
        <div class="overlay toggle-icon"></div>
        <!--end overlay-->
        <!--Start Back To Top Button--> <a href="javaScript:;" class="back-to-top"><i class='bx bxs-up-arrow-alt'></i></a>
        <!--End Back To Top Button-->

        <?php include "theme-footer.php" ?>

        <!--end wrapper-->
        <!-- Bootstrap JS -->
        <script src="../assets/js/bootstrap.bundle.min.js"></script>
        <!--plugins-->
        <script src="../assets/js/jquery.min.js"></script>
        <script src="../assets/plugins/simplebar/js/simplebar.min.js"></script>
        <script src="../assets/plugins/metismenu/js/metisMenu.min.js"></script>
        <script src="../assets/plugins/perfect-scrollbar/js/perfect-scrollbar.js"></script>
        <!--app JS-->
        <script src="../assets/js/app.js"></script>
</body>

</html>