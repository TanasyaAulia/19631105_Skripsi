<!-- <link rel="stylesheet" href="../css/sb-admin-2.min.css"> -->

<style>
* {
  font-family: Arial, Helvetica, sans-serif;
}

</style>

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!--favicon-->
    <link rel="icon" href="../assets/images/logo2.png" type="image/png" />
<title>Laporan Detail Data Pangunjung</title>
</head>
<img src="../assets\images\kop1.png" align=left height="150" width="200">
<img src="../assets/images/kop2.png" align=right height="150" width="200">
<br> <br>
<br> <br>
<br> <br>
<h3 align="center">Laporan Detail Data Pengunjung</h3>
<br>
<div class="table-responsive mt-2">
  <table border="1" width="70%" align="center" cellpadding="8">
    <tbody>
      <?php
      include '../koneksi.php';
      $id_tamu = $_GET['id_tamu'];
   
      $query = mysqli_query($conn, "SELECT * FROM pengunjung WHERE id_tamu = '$id_tamu'");
      while ($data = mysqli_fetch_array($query)) { ?>
      <tr>
        <td width=10%>No.</td>
        <td width=10%> : <?php echo $data['id_tamu'] ?></td>
      </tr>
      <tr>
        <td>Nama Lengkap </td>
        <td> : <?php echo $data['nama_tamu'] ?></td>
      </tr>
      <tr>
        <td>Alamat/Instansi Asal</td>
        <td> : <?php echo $data['alamat'] ?></td>
      </tr>
      <tr>
        <td>No. Telepon</td>
        <td> : <?php echo $data['telp'] ?></td>
      </tr>
      <tr>
        <td>Pegawai yang Ingin Dikunjungi</td>
        <td>:<?php
                         $id_tamu = $_GET['id_tamu'];
                         $query = mysqli_query($conn, "SELECT * FROM pengunjung p, pegawai s WHERE id_tamu = $id_tamu AND s.id_pegawai=p.id_pegawai");
                         while ($data_pegawai = mysqli_fetch_array($query)) { ?>

                        <b><?php echo $data_pegawai['nama_pegawai']; ?></b> 
                      
        </td>
      </tr>
      <tr>
        <td>Keperluan</td>
        <td> : <?php echo $data['tujuan'] ?></td>
      </tr>
     
      <tr>
        <td>Tanggal</td>
        <td> : <?php echo date('d F Y H:i:s') ?></td>
      </tr>
      <tr>
        <td>Status</td>
        <td> :                                   <?php if ($data["status"] == 1) { ?>
                                                    <span><b> Belum Ditemui </b></span>
                                                <?php } else if ($data["status"] == 2) { ?>
                                                    <span> <b>Proses </b></span>
                                                <?php } else if ($data["status"] == 3) { ?>
                                                    <span><b> Sudah Ditemui </b></span>
                                                <?php } ?></td>
      </tr>
     


      <?php
                        }
                        ?>
      
      <?php
      }
      ?>
    </tbody>
  </table>  <br>
    <br>
    <br>
    <br>
    <br>

    <div style="text-align:center">

        <p>Banjarbaru, <?php echo date('d F Y'); ?></p>
      
        <p>
                                            <?php 
                                              $id_tamu = $_GET['id_tamu'];
                                              $query = mysqli_query($conn, "SELECT * FROM pengunjung p, pegawai s WHERE id_tamu = $id_tamu AND s.id_pegawai=p.id_pegawai");
                                              while ($data_pegawai = mysqli_fetch_array($query)) 
                     
                                            $kode = "Laporan Detail Data Pengunjung "."a.n ".$data_pegawai['nama_tamu']." "."Ingin Bertemu ".$data_pegawai['nama_pegawai']." dengan Tujuan ".$data_pegawai['tujuan']."";
                                            require_once('../assets/phpqrcode/qrlib.php');
                                            QRcode::png("$kode","Laporan Detail Data Pengunjung".$id_tamu.".png","S", 4,4);
                                            
                                            ?>
                                            <img src="Laporan Detail Data Pengunjung<?php echo $id_tamu?>.png" alt=""></p>
                                            
                                     
        <p><u><?php
                         $id_tamu = $_GET['id_tamu'];
                         $query = mysqli_query($conn, "SELECT * FROM pengunjung p, pegawai s WHERE id_tamu = $id_tamu AND s.id_pegawai=p.id_pegawai");
                         while ($data_pegawai = mysqli_fetch_array($query)) { ?>

                        <b><?php echo $data_pegawai['nama_pegawai']; ?></b> 
 </u>                       <?php
      }
      ?>
      
                      </p>
                      <p><?php
                         $id_tamu = $_GET['id_tamu'];
                         $query = mysqli_query($conn, "SELECT * FROM pengunjung p, pegawai s WHERE id_tamu = $id_tamu AND s.id_pegawai=p.id_pegawai");
                         while ($data_pegawai = mysqli_fetch_array($query)) { ?>

                        <b>NIP. <?php echo $data_pegawai['nip']; ?></b> </p>
                        <?php
      }
      ?>
    </div>
</div>

<script>
window.print();
</script>