<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="../assets/images/logo2.png" type="image/png" />
    <title>Laporan Data Berkas</title>
    <style>
        * {
            font-family: Arial, Helvetica, sans-serif, center;
        }

        table {
            border-collapse: collapse;
            border-color: black;
        }
    </style>
</head>

<body>
    <img src="../assets\images\kop1.png" align="left" height="150" width="200">
    <img src="../assets/images/kop2.png" align="right" height="150" width="200">
    <br> <br>
    <br> <br>
    <br> <br>
    <h2 align="center">Laporan Data Berkas</h2>
    <div class="table-responsive mt-3">
        <table border="3" width="100%" align="center" cellpadding="8">
            <thead>
                <tr>
                    <th width="2%">No.</th>
                    <th width="7%">Tanggal</th>
                    <th width="10%">Nomor Surat</th>
                    <th width="15%">Nama Lengkap</th>
                    <th width="15%">Alamat</th>
                    <th width="15%">Instansi</th>
                    <th width="5%">No. Telepon</th>
                    <th width="15%">Perihal</th>
                    <th width="10%">Bagian</th>
                    <th width="10%">Status</th>
                </tr>
            </thead>

            <tbody>
                <?php
                include '../koneksi.php';

               
                if(isset($_GET['tipe'])) {
																	
                    if($_GET['tipe'] == "pertanggal") {
                        $from = $_GET['from'];
                        $to = $_GET['to']; 
                        
                        $query = mysqli_query($conn, "SELECT p.*, s.nama_bagian FROM berkas p LEFT JOIN bagian s ON p.id_bagian = s.id_bagian WHERE DATE(tanggal) BETWEEN '$from' AND '$to' ORDER BY id_berkas ASC");
                    }else if($_GET['tipe'] == "perbulan") {
                        $bulan = $_GET['bulan'];
                        $tahun = $_GET['tahun'];
                        
                        $query = mysqli_query($conn, "SELECT p.*, s.nama_bagian FROM berkas p LEFT JOIN bagian s ON p.id_bagian = s.id_bagian WHERE DATE(tanggal) LIKE '$tahun-$bulan%' ORDER BY id_berkas ASC");
                    }else if($_GET['tipe'] == "pertahun") {
                        $tahun = $_GET['tahun'];

                        $query = mysqli_query($conn, "SELECT p.*, s.nama_bagian FROM berkas p LEFT JOIN bagian s ON p.id_bagian = s.id_bagian WHERE tanggal LIKE '$tahun%' ORDER BY id_berkas ASC");
                    }else {
                        $query = mysqli_query($conn, "SELECT p.*, s.nama_bagian FROM berkas p LEFT JOIN bagian s ON p.id_bagian = s.id_bagian WHERE ORDER BY id_berkas ASC");
                    }
                    
                }else {
                    $query = mysqli_query($conn, "SELECT p.*, s.nama_bagian FROM berkas p LEFT JOIN bagian s ON p.id_bagian = s.id_bagian WHERE ORDER BY id_berkas ASC");
                }
$no = 1;
while ($data = mysqli_fetch_array($result)) {
                ?>
                    <tr>
                        <td><?php echo $no++ ?></td>
                        <td><?php echo $data['tanggal'] ?></td>
                        <td><?php echo $data['no_surat'] ?></td>
                        <td><?php echo $data['nama'] ?></td>
                        <td><?php echo $data['alamat'] ?></td>
                        <td><?php echo $data['instansi'] ?></td>
                        <td><?php echo $data['telp'] ?></td>
                        <td><?php echo $data['perihal'] ?></td>
                        <td>
                       <b><?php echo $data['nama_bagian'] ?></b> 
                        </td>
                        <td>
                            <?php if ($data["status"] == 1) { ?>
                                <span>Belum Diverifikasi</span>
                            <?php } else if ($data["status"] == 2) { ?>
                                <span>Dalam Proses</span>
                            <?php } else if ($data["status"] == 3) { ?>
                                <span>Terverifikasi</span>
                            <?php } ?>
                        </td>
                       
                    </tr>
                <?php
                }
                ?>

            </tbody>
        </table>
        <br>
        <br>
        <br>
        <br>
        <br>
        <div style="text-align:center">

            <p>Banjarbaru, <?php echo date('d F Y'); ?></p>
            <p>
                                            <?php 
                                             $query = "SELECT p.*, s.nama_bagian FROM berkas p LEFT JOIN bagian s ON p.id_bagian = s.id_bagian";
                                               $result = mysqli_query($conn, $query);
                                               while ($data = mysqli_fetch_array($result))
                     
                                               $uri_path = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
                                               $uri_segments = explode('/', $uri_path);
                                               $baseURL = 'http://'.getHostByName(getHostName()).'/'.$_SERVER["REQUEST_URI"];
                                               
                                               $directoryURI = $_SERVER['REQUEST_URI'];
                                               $parseURI = parse_url($directoryURI, PHP_URL_PATH);
                                               $componentsURI = explode('/', $parseURI);
                                               $pathURI = $componentsURI[2];

                                            $kode = $baseURL;
                                            require_once('../assets/phpqrcode/qrlib.php');
                                            QRcode::png("$kode","Laporan".$data.".png","M", 4,4);
                                            
                                            ?>
                                            <img src="Laporan<?php echo $data?>.png" alt=""></p>
            <p><b>General Manager</b></p>
        </div>
    </div>

    <script>
        window.print();
    </script>
</body>

</html>
