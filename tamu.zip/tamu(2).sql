-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 23 Nov 2023 pada 14.24
-- Versi server: 10.4.27-MariaDB
-- Versi PHP: 7.4.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `tamu`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `bagian`
--

CREATE TABLE `bagian` (
  `id_bagian` int(11) NOT NULL,
  `nama_bagian` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;

--
-- Dumping data untuk tabel `bagian`
--

INSERT INTO `bagian` (`id_bagian`, `nama_bagian`) VALUES
(1, 'General Manager'),
(2, 'Airport Technology'),
(3, 'Stakeholder Relation'),
(4, 'General Service'),
(5, 'Legal and Compliance'),
(6, 'Operation Center'),
(7, 'Safety Management System and Occupational Safety Health'),
(8, 'Quality, Risk and Performance'),
(9, 'Airport Environment'),
(10, 'Airport Operation, Services and Security'),
(11, 'Operation Air Side'),
(12, 'Operation Land Side, Terminal and Services Improvement'),
(13, 'Airport Rescue and Fire Fighting'),
(14, 'Airport Security'),
(15, 'Airport Technical Senior'),
(16, 'Airport Facilities'),
(17, 'Airport Equipment'),
(18, 'Airport Commercial Senior'),
(19, 'Airport Aeronautical'),
(20, 'Airport Non Aeronautical'),
(21, 'Airport Administration'),
(22, 'Finance Manager'),
(23, 'Accounting Manager');

-- --------------------------------------------------------

--
-- Struktur dari tabel `berkas`
--

CREATE TABLE `berkas` (
  `id_berkas` int(11) NOT NULL,
  `tanggal` datetime NOT NULL,
  `status` varchar(100) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `alamat` varchar(200) NOT NULL,
  `instansi` varchar(100) NOT NULL,
  `telp` varchar(15) NOT NULL,
  `no_surat` varchar(100) NOT NULL,
  `perihal` varchar(100) NOT NULL,
  `id_bagian` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;

--
-- Dumping data untuk tabel `berkas`
--

INSERT INTO `berkas` (`id_berkas`, `tanggal`, `status`, `nama`, `alamat`, `instansi`, `telp`, `no_surat`, `perihal`, `id_bagian`) VALUES
(2, '2023-07-24 14:26:04', '3', 'Dea Putri Annisa', 'Jl. Mistarcokrokusumo, Sungai Besar', 'Universitas Islam Kalimantan', '089876545676', '263/UNISKA-FTI/A-15/IX/2022', 'Surat Pengajuan PKL', 5),
(12, '2023-07-24 15:34:46', '3', 'Yona Maudita', 'Jl. Bincau Indah 1, Martapura', 'Dinas Kesehatan', '085251649933', 'HK.02.02/MENKES/377/2023', 'Surat Pengolahan Lingkungan Sehat', 6),
(13, '2023-08-04 19:28:19', '1', 'Praptono', 'Jl. Jend. Sudirman, Banjarmasin', 'Kementrian Pendidikan,Kebudayaan,Riset, dan Teknologi', '089852848201', '5673/B.B2/GT.04.08/2023', 'Perizinan Praktek Lapangan', 6),
(14, '2023-08-04 19:32:03', '2', 'Sudia Permana', 'Jl. Jend. A. Yani No. 239', 'Dinas Pendidikan', '081219478391', '005/0323/Disdik', 'Undangan', 6),
(15, '2023-08-04 19:34:33', '1', 'Alena Mahda', 'Hulu Sungai Utara', 'Puskesmas Hulu Sungai Utara', '089830862917', '441/078/Dinkes/2023', 'Pertemuan BimTek', 8),
(16, '2023-08-11 20:04:49', '1', 'Setiawan Wangsaatmaja', 'Jl. Bhayangara No.1, Sungai Besar, Kec. Banjarbaru Selatan', 'Kantor Regional VIII Badan Kepegawaian Negara', '081229379201', 'B/36/SM.01.00/2023', 'Undangan Rapat Koordinasi', 1),
(19, '2023-08-26 14:21:12', '1', 'Dewi Puspita', 'Sungai Ulin', 'Kecamatan Banjarbaru Utara', '089826183928', '78/RM/VII/2023', 'Undangan', 1);

-- --------------------------------------------------------

--
-- Struktur dari tabel `calon_mitra`
--

CREATE TABLE `calon_mitra` (
  `id_cm` int(11) NOT NULL,
  `tanggal` datetime NOT NULL,
  `status` varchar(20) NOT NULL,
  `nama_cm` varchar(100) NOT NULL,
  `alamat` varchar(200) NOT NULL,
  `telp` varchar(15) NOT NULL,
  `sektor` varchar(100) NOT NULL,
  `produk` varchar(100) NOT NULL,
  `penghasilan` varchar(100) NOT NULL,
  `jangka_waktu` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;

--
-- Dumping data untuk tabel `calon_mitra`
--

INSERT INTO `calon_mitra` (`id_cm`, `tanggal`, `status`, `nama_cm`, `alamat`, `telp`, `sektor`, `produk`, `penghasilan`, `jangka_waktu`) VALUES
(8, '2023-07-21 21:53:23', '3', 'Wafika Aziza', 'Jl. Indrasari, Martapura', '0897556532356', 'Peternakan', 'Itik', 'Rp500.000 - Rp1.000.000', '6 Bulan'),
(10, '2023-07-24 10:21:52', '3', 'Tina Andini', 'Jl. Sekumpul Ujung, Gg. Muharam, Martapura', '085251649933', 'Jasa', 'Aksesoris Kokka', 'Rp500.000 - Rp1.000.000', '2 Bulan'),
(14, '2023-07-24 19:26:48', '1', 'Desy Utami', 'Jl. Kenanga, Pintu Air, Martapura', '087698897908', 'Perdagangan', 'Sembako', 'Rp500.000 - Rp1.000.000', '1 Tahun'),
(15, '2023-08-04 19:16:55', '1', 'Dina Ayunda', 'Jl. Sapta Marga Gg.Virgo, Landasan Ulin', '085298182673', 'Perdagangan', 'Sembako', 'Rp500.000 - Rp1.000.000', '1 Tahun'),
(16, '2023-08-04 19:18:43', '2', 'Lussy Saputri', 'Jl. Sidomulyo 1, Sungai Besar', '089827108652', 'Perdagangan', 'Makanan  ', 'Rp500.000 - Rp1.000.000', '6 Bulan'),
(17, '2023-08-11 19:43:10', '1', 'Rieya Deswita', 'Jl. Veteran RT/RW 010/005, Sungai Sipai', '085209673920', 'Jasa', 'Pakaian Jadi', 'Rp1.000.000 - Rp2.000.000', '1 Tahun'),
(31, '2023-08-26 14:20:22', '1', 'Meghani ', 'Jl. Bhayangkara No.1, Sungai Besar, Kec. Banjarbaru Selatan', '087587512303', 'Perkebunan', 'Jagung', 'Rp1.000.000 - Rp2.000.000', '1 Tahun');

-- --------------------------------------------------------

--
-- Struktur dari tabel `paket`
--

CREATE TABLE `paket` (
  `id_paket` int(11) NOT NULL,
  `tanggal` datetime NOT NULL,
  `no_resi` varchar(100) NOT NULL,
  `jenis` varchar(100) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `alamat` varchar(200) NOT NULL,
  `telp` varchar(15) NOT NULL,
  `ekspedisi` varchar(100) NOT NULL,
  `id_pegawai` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;

--
-- Dumping data untuk tabel `paket`
--

INSERT INTO `paket` (`id_paket`, `tanggal`, `no_resi`, `jenis`, `nama`, `alamat`, `telp`, `ekspedisi`, `id_pegawai`) VALUES
(2, '2023-07-21 14:11:04', '001442365534', 'Paket', 'Fahmi Putra', 'Jl. Kenanga, Pintu Air, Martapura', '088383312313', 'SiCepat Express', 8),
(3, '2023-07-24 15:57:26', '	BLIAJS0000037169080', 'Paket', 'Agus Permana', 'Jl. Sekumpul Ujung, Gg. Mahabbah, Martapura', '087698897908', 'AnterAja', 11),
(4, '2023-08-04 15:50:44', '	IDD150963332202', 'Paket', 'Adriansah', 'Jl. Jend. A. Yani No. 301', '089826183928', 'ID Express', 10),
(5, '2023-08-04 15:55:22', 'PLMAA161575229999', 'Paket', 'Rasidi', 'Jl. Indrasari, Martapura', '081258064722', 'AnterAja', 9),
(6, '2023-08-04 19:41:29', '	P2107150095165', 'Paket', 'Aldin Ramadhan', 'Gg. Sempurna, Tanjung Rema', '087824829282', 'POS Indonesia', 4),
(7, '2023-08-04 19:42:23', 'ID012490109268', 'Paket', 'Hidayat', 'Jl. Indrasari, Martapura', '08982648593729', 'ID Express', 5),
(9, '2023-08-25 21:17:35', 'IDD127634401202', 'Paket', 'Adriansah', 'Tanjung Rema', '088383312313', 'ID Express', 8);

-- --------------------------------------------------------

--
-- Struktur dari tabel `pegawai`
--

CREATE TABLE `pegawai` (
  `id_pegawai` int(11) NOT NULL,
  `nip` varchar(50) NOT NULL,
  `status` varchar(11) NOT NULL,
  `nama_pegawai` varchar(200) NOT NULL,
  `id_bagian` int(11) NOT NULL,
  `email` varchar(50) NOT NULL,
  `telp` varchar(15) NOT NULL,
  `tgl_reg` datetime NOT NULL,
  `level` varchar(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;

--
-- Dumping data untuk tabel `pegawai`
--

INSERT INTO `pegawai` (`id_pegawai`, `nip`, `status`, `nama_pegawai`, `id_bagian`, `email`, `telp`, `tgl_reg`, `level`) VALUES
(1, '9676021-D', '1', 'Dony Subardono', 1, 'donysubardono@gmail.com', '08123825616', '2023-07-26 22:38:33', '2'),
(2, '14900700-D', '2', 'Donny Agung Novanto', 6, 'donnyanovanto@gmail.com', '082221158274', '2023-07-26 22:58:10', ''),
(3, '9776074-A', '1', 'Ahmad Zulfian Noor', 3, 'zulfiannoor@gmail.com', '085251649933', '2023-07-26 22:59:29', ''),
(4, '9874053-A', '1', 'Abdi Purnomo', 25, 'abdipurnomo1@gmail.com', '085382078900', '2023-08-04 09:57:07', ''),
(5, '9068681-M', '1', 'Mohammad Yusuf', 6, 'yusufmohammad@gmail.com', '08125806472', '2023-08-04 09:58:39', ''),
(6, '9469016-S', '1', 'Sutikno Ariwibowo', 6, 'sutiknoariwibowo@gmail.com', '081348306455', '2023-08-04 10:01:40', ''),
(7, '9977087-A', '1', 'Agus Agung Hariyadi', 6, 'agushariyadi@gmail.com', '082144077942', '2023-08-04 10:08:03', ''),
(8, '9777048-I', '1', 'Iwan Satriya Graha', 6, 'iwansgraha@gmail.com', '081235739986', '2023-08-04 10:09:14', ''),
(9, '9673046-S', '1', 'Siswanto Purnomo', 10, 'siswanto1985@gmail.com', '081387407671', '2023-08-04 10:10:16', ''),
(10, '0781042-D', '1', 'Dicky Samudra Pangaksomo', 11, 'dickysamudra15@gmail.com', '081254440706', '2023-08-04 13:07:40', ''),
(11, '0682161-M', '1', 'M. Tri Wiluyo Puspoyudo', 12, 'mtriwiluyo@gmail.com', '08111002682', '2023-08-04 13:09:20', ''),
(13, '0283010-M', '1', 'M. Gazali Abdurrahman', 14, 'gazaliabdurrahman@gmail.com', '082191297765', '2023-08-04 13:18:10', ''),
(14, '0675037-B', '1', 'Budi Rano Sulistyo', 15, 'ranosulistyo@gmail.com', '081319815131', '2023-08-10 23:51:50', '');

-- --------------------------------------------------------

--
-- Struktur dari tabel `penawaran`
--

CREATE TABLE `penawaran` (
  `id_penawaran` int(11) NOT NULL,
  `tanggal` datetime NOT NULL,
  `nama` varchar(100) NOT NULL,
  `alamat` varchar(200) NOT NULL,
  `instansi` varchar(100) NOT NULL,
  `telp` varchar(15) NOT NULL,
  `produk_jasa` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;

--
-- Dumping data untuk tabel `penawaran`
--

INSERT INTO `penawaran` (`id_penawaran`, `tanggal`, `nama`, `alamat`, `instansi`, `telp`, `produk_jasa`) VALUES
(1, '2023-07-06 14:50:08', 'Syfa Aprilia', 'Jl. Bincau Indah 2, Martapura', 'Mycakeu Korean Lunch Box Cake', '0812345678903', 'Korean Lunch Box'),
(2, '2023-07-30 09:44:42', 'Abdul Fajar', 'Gg. Saadah 2 No. 21, Sungai Paring', 'PT.Twincom', '0897556532356', 'Laptop'),
(3, '2023-08-04 19:09:03', 'Nur Khafifah', 'Jl. Sempurna No.2, Sungai Sipai', 'Toko Mama Ifah', '089817639201', 'Makanan Olahan Rumah'),
(4, '2023-08-04 19:11:31', 'Zulfa Seff', 'Jl. Perambaian, Sungai Ulin', 'CV. Mitra Consultant', '089752067419', 'Konsultan Infrastruktur Bangunan'),
(5, '2023-08-04 19:11:51', 'Ronna Lisa', 'Gg. Saadah 1 No. 57 Blok A, Sungai Paring', 'Toko Bunga Amora Florist', '082200192030', 'Karangan Bunga'),
(9, '2023-08-26 14:19:16', 'Dian Ayu', 'Jl. Jeruk, Sungai Ulin', 'PT. Asuransi Jaya', '089826183928', 'Asuransi');

-- --------------------------------------------------------

--
-- Struktur dari tabel `pengunjung`
--

CREATE TABLE `pengunjung` (
  `id_tamu` int(11) NOT NULL,
  `status` varchar(11) NOT NULL,
  `nama_tamu` varchar(100) NOT NULL,
  `alamat` varchar(200) NOT NULL,
  `telp` varchar(15) NOT NULL,
  `id_pegawai` int(11) NOT NULL,
  `tujuan` varchar(200) NOT NULL,
  `tanggal` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;

--
-- Dumping data untuk tabel `pengunjung`
--

INSERT INTO `pengunjung` (`id_tamu`, `status`, `nama_tamu`, `alamat`, `telp`, `id_pegawai`, `tujuan`, `tanggal`) VALUES
(1, '3', 'Abdul Hamid', 'Jl. Veteran, Sungai Sipai', '089818372819', 7, 'Pengambilan Data Kantor ', '2023-07-05 09:33:15'),
(2, '3', 'Muhammad Dani', 'Komp. Permata Hijau Blok M, Banjarbaru Utara', '08139877283901', 6, 'Kunjungan Teman', '2023-07-10 21:06:12'),
(6, '1', 'Akhmad Luthfiannor', 'Jl. Sapta Marga, Landasan Ulin', '085398702038', 3, 'Pengecekan Persyaratan Calon Mitra Binaan', '2023-07-10 21:28:26'),
(43, '3', 'Dedy Reswandy', 'Jl. Pandai Tengah, Kandangan', '085251649933', 9, 'Penelitian Data Kantor', '2023-07-30 08:59:24'),
(44, '1', 'Aulia Fitri', 'Gg. Sempurna, Tanjung Rema', '081319815131', 3, 'Pengecekan Persyaratan Calon Mitra Binaan', '2023-08-04 15:10:46'),
(46, '2', 'Wedy Setiady', 'Jl. Wengga, Gg. Kuda Kencana, Guntung Manggis', '089865128627', 4, 'Pembahasan Mengenai Bangunan Infrastruktur Kantor', '2023-08-04 18:52:36'),
(47, '2', 'Noorwanda Ristania', 'Jl. Sekumpul Ujung, Gg. Hijrah, Martapura', '085387001020', 10, 'Penelitian Tugas Perkuliahan', '2023-08-04 18:59:33'),
(48, '2', 'Shaquila Syifa', 'Komp. Citra Garden City, Sungai Ulin', '085210985628', 10, 'Penelitian Tugas Perkuliahan', '2023-08-04 19:02:04'),
(49, '3', 'Amaliah Rizky', 'Jl. Sungai Kacang, Sekumpul', '087823017593', 2, 'Penelitian Tugas Perkuliahan', '2023-08-04 19:50:50'),
(50, '3', 'Nazla Aulia', 'Jl. Jend. Sudirman, Banjarmasin', '081284028048', 3, 'Pengajuan PKL', '2023-08-04 19:52:37'),
(52, '1', 'Nadia Bilqis', 'Aluh-Aluh Besar RT.01 No. 42, Banjarmasin', '089647102910', 5, 'Penelitian Data Kantor', '2023-08-11 11:56:04'),
(53, '2', 'Selisa Norina', 'Jl. Indrasari No. 40, Martapura', '089816283928', 8, 'Kunjungan Teman', '2023-08-18 00:08:33'),
(56, '1', 'Abdul Lathif', 'Sungai sipai', '089826183928', 10, 'Pengajuan PKL', '2023-08-19 18:21:30'),
(58, '3', 'Perdana', 'Jl. Veteran, Sungai Sipai', '081258064722', 8, 'Penelitian Data Kantor', '2023-08-21 23:02:39'),
(60, '1', 'Putri Ariani', 'Desa Keramat, Kec. Martapura Timur', '089754920172', 3, 'Penelitian Tugas Perkuliahan', '2023-08-26 14:18:30'),
(62, '1', 'Rafflie', 'Jl. Indrasari, Martapura', '089876545676', 10, 'Pengajuan PKL', '2023-11-23 21:10:59');

-- --------------------------------------------------------

--
-- Struktur dari tabel `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `nama_user` varchar(200) NOT NULL,
  `username` varchar(200) NOT NULL,
  `password` varchar(200) NOT NULL,
  `email` varchar(100) NOT NULL,
  `telp` varchar(15) NOT NULL,
  `foto` varchar(100) NOT NULL,
  `level` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  `tgl_reg` datetime NOT NULL,
  `theme` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;

--
-- Dumping data untuk tabel `user`
--

INSERT INTO `user` (`id`, `nama_user`, `username`, `password`, `email`, `telp`, `foto`, `level`, `status`, `tgl_reg`, `theme`) VALUES
(1, 'Tanasya Aulia', 'nasya', '$2y$10$xYN0/TkebG1xmecJ66AnsOX.cn098615uBUyb5bP.YjDQ8xaZYzjy', 'tanasyaaulia@gmail.com', '082351602075', 'user.png', 1, 1, '2023-07-04 15:22:06', 'semi-dark');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `bagian`
--
ALTER TABLE `bagian`
  ADD PRIMARY KEY (`id_bagian`) USING BTREE;

--
-- Indeks untuk tabel `berkas`
--
ALTER TABLE `berkas`
  ADD PRIMARY KEY (`id_berkas`) USING BTREE;

--
-- Indeks untuk tabel `calon_mitra`
--
ALTER TABLE `calon_mitra`
  ADD PRIMARY KEY (`id_cm`) USING BTREE;

--
-- Indeks untuk tabel `paket`
--
ALTER TABLE `paket`
  ADD PRIMARY KEY (`id_paket`) USING BTREE,
  ADD KEY `id_pegawai` (`id_pegawai`) USING BTREE;

--
-- Indeks untuk tabel `pegawai`
--
ALTER TABLE `pegawai`
  ADD PRIMARY KEY (`id_pegawai`) USING BTREE;

--
-- Indeks untuk tabel `penawaran`
--
ALTER TABLE `penawaran`
  ADD PRIMARY KEY (`id_penawaran`) USING BTREE;

--
-- Indeks untuk tabel `pengunjung`
--
ALTER TABLE `pengunjung`
  ADD PRIMARY KEY (`id_tamu`) USING BTREE,
  ADD KEY `id_pegawai` (`id_pegawai`) USING BTREE;

--
-- Indeks untuk tabel `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`) USING BTREE;

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `bagian`
--
ALTER TABLE `bagian`
  MODIFY `id_bagian` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- AUTO_INCREMENT untuk tabel `berkas`
--
ALTER TABLE `berkas`
  MODIFY `id_berkas` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT untuk tabel `calon_mitra`
--
ALTER TABLE `calon_mitra`
  MODIFY `id_cm` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- AUTO_INCREMENT untuk tabel `paket`
--
ALTER TABLE `paket`
  MODIFY `id_paket` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT untuk tabel `pegawai`
--
ALTER TABLE `pegawai`
  MODIFY `id_pegawai` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT untuk tabel `penawaran`
--
ALTER TABLE `penawaran`
  MODIFY `id_penawaran` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT untuk tabel `pengunjung`
--
ALTER TABLE `pengunjung`
  MODIFY `id_tamu` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=63;

--
-- AUTO_INCREMENT untuk tabel `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
